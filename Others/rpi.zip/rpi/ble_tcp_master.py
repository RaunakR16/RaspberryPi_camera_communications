# # master_wifi_controller.py
# import socket
# import time
# import threading
# import json
# import os
# from bluezero import peripheral
# import cv2
# import numpy as np

# folder_path = '\home\rpiez\received_images'

# def clear_image_folder(folder_path = '\home\rpiez\received_images'):
#     """Clear all images in the received images folder"""
#     if not os.path.exists(folder_path):
#         os.makedirs(folder_path)
    
#     # Remove all files in the folder
#     for filename in os.listdir(folder_path):
#         file_path = os.path.join(folder_path, filename)
#         if os.path.isfile(file_path):
#             os.remove(file_path)

# clear_image_folder()  # Clear the image folder at startup

# ADAPTER_ADDR = 'B8:27:EB:02:72:71'  # Replace with your Pi's Bluetooth MAC
# my_device = peripheral.Peripheral(adapter_address=ADAPTER_ADDR, local_name=f'master')

# def write_callback(value, options):
#     command = value.decode()
#     print(f"Received command: {command}")
#     if command.strip() == "capture":
#         threading.Thread(target=send_capture_to_all_slaves).start()

# # Replace with your actual slave Pi hostnames
# SLAVE_HOSTS = {
#     1: 'slcam01.local',
#     2: 'slcam02.local', 
#     3: 'slcam03.local',
#     4: 'slcam04.local',
#     5: 'slcam05.local',
#     # Add more slaves as needed
# }   

# SLAVE_PORT = 8888  # Port that slaves will listen on
# TIMEOUT = 30  # Timeout in seconds
# MASTER_IMAGE_DIR = "/home/rpiez/received_images"  # Directory to save received images

# # Create master image directory
# os.makedirs(MASTER_IMAGE_DIR, exist_ok=True)

# result = []

# def process_image_data(device = my_device, folder_path='\home\rpiez\received_images' ):
#     for filename in os.listdir(folder_path):
#         file_path = os.path.join(folder_path, filename)
#         if os.path.isfile(file_path):
#             try:
#                 # Process the image file (e.g., analyze, display, etc.)
#                 print(f"Processing image: {filename}")
#                 # Load target and template images
#                 target_path = file_path
#                 template_path = '\home\rpiez\tcp\template_1.jpg'
#                 j=0
#                 k=400
#                 c=1
#                 l=[]
#                 while k<=800:
#                     target = cv2.imread(target_path)[:,j:k]
#                     template = cv2.imread(template_path)
            
#                     # Convert to grayscale
#                     target_gray = cv2.cvtColor(target, cv2.COLOR_BGR2GRAY)
#                     template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
            
#                     # Enhance contrast with histogram equalization
#                     target_gray = cv2.equalizeHist(target_gray)
#                     template_gray = cv2.equalizeHist(template_gray)
            
#                     # Apply Canny edge detection for robustness
#                     target_edges = cv2.Canny(target_gray, 50, 150)
#                     template_edges = cv2.Canny(template_gray, 50, 150)
            
#                     # Template matching
#                     res = cv2.matchTemplate(target_edges, template_edges, cv2.TM_CCOEFF_NORMED)
#                     _, max_val, _, max_loc = cv2.minMaxLoc(res)
            
#                     # Get template size
#                     h, w = template_gray.shape
            
#                     # Define bounding box of matched region
#                     top_left = max_loc
#                     bottom_right = (top_left[0] + w, top_left[1] + h)
            
#                     # Crop the region
#                     cropped = target[top_left[1]:bottom_right[1], top_left[0]:bottom_right[0]]
            
#                     gray = cv2.cvtColor(cropped, cv2.COLOR_BGR2GRAY)
#                     blur = cv2.medianBlur(gray, 19)
#                     sharpen_kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
#                     sharpen = cv2.filter2D(blur, -1, sharpen_kernel)
            
#                     # Threshold and morph close
#                     thresh = cv2.threshold(sharpen, 105, 185, cv2.THRESH_BINARY_INV)[1]
#                     kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
#                     close = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=2)
            
            
#                     count = 0
#                     i=50
#                     while i <220:
#                         if np.sum(close[i:i+10,:])>60000:
#                             i = i+40
#                             count+=1
#                         else:
#                             i+=1
#                     print(f'image--{c}')
#                     if count ==2:
#                         print('Both C and T are available')
#                     elif count==1:
#                         print('Only C is available')
#                     elif count==0:
#                         print('Invalid')
#                     else:
#                         print('Wrong Output')
#                     l.extend([c, count])
#                     c+=1
#                     j=k
#                     k+=400
                
#                 # Add your image processing logic here
#                 print(f"Image {filename} processed successfully.")
#                 device.update_characteristic_value(result.encode('utf-8'))
#             except Exception as e:
#                 print(f"Error processing image {filename}: {e}")
#                 device.update_characteristic_value(f"Error processing {filename}: {e}".encode('utf-8'))
#     clear_image_folder(folder_path)  # Clear folder after processing
#     return result

# def receive_image_from_slave(sock, slave_id, response_data):
#     """Receive image file from slave"""
#     try:
#         # Receive file size
#         size_data = sock.recv(1024).decode().strip()
#         file_size = int(size_data)
#         print(f"[MASTER] Expecting image of {file_size} bytes from Slave {slave_id}")
        
#         # Send acknowledgment
#         sock.send("READY".encode())
        
#         # Receive file data
#         received_data = b""
#         bytes_received = 0
        
#         while bytes_received < file_size:
#             chunk = sock.recv(min(4096, file_size - bytes_received))
#             if not chunk:
#                 break
#             received_data += chunk
#             bytes_received += len(chunk)
            
#             # Show progress for large files
#             if file_size > 100000:  # Show progress for files > 100KB
#                 progress = (bytes_received / file_size) * 100
#                 print(f"[MASTER] Receiving from Slave {slave_id}: {progress:.1f}%")
        
#         if bytes_received == file_size:
#             # Save the image
#             timestamp = int(time.time())
#             filename = f"master_received_slave{slave_id}_{timestamp}.jpg"
#             filepath = os.path.join(MASTER_IMAGE_DIR, filename)
            
#             with open(filepath, 'wb') as f:
#                 f.write(received_data)
            
#             print(f"[MASTER] Image saved from Slave {slave_id}: {filename}")
#             process_image_data()
#             return {
#                 "success": True,
#                 "filepath": filepath,
#                 "filename": filename,
#                 "size": file_size
#             }
#         else:
#             print(f"[MASTER] Incomplete image received from Slave {slave_id}")
#             return {"success": False, "error": "Incomplete transfer"}
            
#     except Exception as e:
#         print(f"[MASTER] Error receiving image from Slave {slave_id}: {e}")
#         return {"success": False, "error": str(e)}

# def send_capture_command(slave_host, slave_id, receive_image=True):
#     """Send capture command to a slave and optionally receive the image"""
#     try:
#         print(f"[MASTER] Connecting to Slave {slave_id} at {slave_host}:{SLAVE_PORT}...")
        
#         # Create socket and connect
#         sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#         sock.settimeout(TIMEOUT)
#         sock.connect((slave_host, SLAVE_PORT))
        
#         print(f"[MASTER] Connected to Slave {slave_id}")
        
#         # Send capture command
#         command = {
#             "action": "capture",
#             "timestamp": time.time(),
#             "send_image": receive_image
#         }
#         message = json.dumps(command) + '\n'
#         sock.send(message.encode())
#         print(f"[MASTER] Sent capture command to Slave {slave_id}")
        
#         # Wait for response
#         response = sock.recv(1024).decode().strip()
#         response_data = json.loads(response)
        
#         print(f"[MASTER] Response from Slave {slave_id}: {response_data['message']}")
        
#         if response_data['status'] == 'success':
#             print(f"[MASTER] Slave {slave_id} successfully captured image")
            
#             # Receive image if requested and capture was successful
#             if receive_image:
#                 image_result = receive_image_from_slave(sock, slave_id, response_data)
#                 if image_result['success']:
#                     print(f"[MASTER] Image successfully received from Slave {slave_id}")
#                 else:
#                     print(f"[MASTER] Failed to receive image from Slave {slave_id}: {image_result.get('error')}")
#         else:
#             print(f"[MASTER] Slave {slave_id} failed to capture image: {response_data.get('error', 'Unknown error')}")
            
#     except socket.timeout:
#         print(f"[MASTER] Timeout waiting for Slave {slave_id}")
#     except ConnectionRefusedError:
#         print(f"[MASTER] Could not connect to Slave {slave_id} - service not running")
#     except Exception as e:
#         print(f"[MASTER] Error communicating with Slave {slave_id}: {e}")
#     finally:
#         try:
#             sock.close()
#         except:
#             pass

# def send_capture_to_all_slaves(receive_images=True):
#     """Send capture command to all slaves simultaneously"""
#     threads = []
    
#     for slave_id, slave_host in SLAVE_HOSTS.items():
#         thread = threading.Thread(
#             target=send_capture_command, 
#             args=(slave_host, slave_id, receive_images)
#         )
#         threads.append(thread)
#         thread.start()
    
#     # Wait for all threads to complete
#     for thread in threads:
#         thread.join()

# if __name__ == "__main__":
#     print("[MASTER] Starting BLE WiFi Camera Controller")
#     print(f"[MASTER] Using Bluetooth adapter: {ADAPTER_ADDR}")

#     my_device.add_service(srv_id=1, uuid='12345678-1234-5678-1234-56789abcdef0', primary=True)
#     my_device.add_characteristic(
#         srv_id=1,
#         chr_id=1,
#         uuid='abcd1234-5678-4321-1234-fedcba987654',
#         value=f"master Ready".encode(),
#         notifying=True,
#         flags=['write', 'notify'],
#         write_callback=lambda value, options: write_callback(value, options)
#     )
#     my_device.add_characteristic(
#     srv_id=1,
#     chr_id=2,
#     uuid='abcd1234-5678-4321-1234-fedcba987655',
#     value=f"master Ready".encode(),
#     notifying=True,
#     flags=['read', 'notify'],
# )
#     print(f"Master BLE advertising started...")
#     my_device.publish()






# # master_wifi_controller.py
# import socket
# import time
# import threading
# import json
# import os
# from bluezero import peripheral
# import cv2
# import numpy as np

# folder_path = '/home/rpiez/received_images'  # Fixed path separators

# def clear_image_folder(folder_path='/home/rpiez/received_images'):  # Fixed path separators
#     """Clear all images in the received images folder"""
#     if not os.path.exists(folder_path):
#         os.makedirs(folder_path)
    
#     # Remove all files in the folder
#     for filename in os.listdir(folder_path):
#         file_path = os.path.join(folder_path, filename)
#         if os.path.isfile(file_path):
#             os.remove(file_path)

# clear_image_folder()  # Clear the image folder at startup

# ADAPTER_ADDR = 'B8:27:EB:02:72:71'  # Replace with your Pi's Bluetooth MAC
# my_device = peripheral.Peripheral(adapter_address=ADAPTER_ADDR, local_name=f'master')

# result = None  # Global result variable

# def write_callback(value, options):
#     command = value.decode()
#     print(f"Received command: {command}")
#     if command.strip() == "capture":
#         threading.Thread(target=send_capture_to_all_slaves).start()
    
#     if result is not None:
#         threading.Thread(target=result_and_notify, args=(my_device,).start())

# def result_and_notify(device):
#     print(f"Sending result: {result}")
#     if result is not None:
#         device.update_characteristic_value(1, result.encode())

# # Replace with your actual slave Pi hostnames
# SLAVE_HOSTS = {
#     1: 'slcam01.local',
#     2: 'slcam02.local', 
#     3: 'slcam03.local',
#     4: 'slcam04.local',
#     5: 'slcam05.local',
#     # Add more slaves as needed
# }   

# SLAVE_PORT = 8888  # Port that slaves will listen on
# TIMEOUT = 30  # Timeout in seconds
# MASTER_IMAGE_DIR = "/home/rpiez/received_images"  # Directory to save received images

# # Create master image directory
# os.makedirs(MASTER_IMAGE_DIR, exist_ok=True)


# def process_image_data(device=None, folder_path='/home/rpiez/received_images'):
#     """Process images and update BLE characteristic with results"""
#     global result
#     result = []  # Reset result
    
#     try:
#         print(f"Processing images in folder: {folder_path}")
        
#         if not os.path.exists(folder_path):
#             print(f"Folder {folder_path} does not exist")
#             return result
            
#         image_files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
        
#         if not image_files:
#             print("No image files found to process")
#             return result
            
#         print(f"Found {len(image_files)} image files to process")
        
#         for filename in image_files:
#             file_path = os.path.join(folder_path, filename)
#             if os.path.isfile(file_path):
#                 try:
#                     # Process the image file (e.g., analyze, display, etc.)
#                     print(f"Processing image: {filename}")
#                     # Load target and template images
#                     target_path = file_path
#                     template_path = '/home/rpiez/tcp/template_1.jpg'  # Fixed path separators
                    
#                     if not os.path.exists(template_path):
#                         print(f"Template file not found: {template_path}")
#                         continue
                        
#                     j = 0
#                     k = 400
#                     c = 1
#                     l = []
                    
#                     # Read the full target image first to check dimensions
#                     full_target = cv2.imread(target_path)
#                     if full_target is None:
#                         print(f"Could not read image: {target_path}")
#                         continue
                        
#                     image_width = full_target.shape[1]
#                     print(f"Image width: {image_width}")
                    
#                     while k <= min(800, image_width):  # Don't exceed image width
#                         target = cv2.imread(target_path)[:, j:k]
#                         template = cv2.imread(template_path)
                        
#                         if target is None or template is None:
#                             print(f"Could not read target or template image")
#                             break
                
#                         # Convert to grayscale
#                         target_gray = cv2.cvtColor(target, cv2.COLOR_BGR2GRAY)
#                         template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
                
#                         # Enhance contrast with histogram equalization
#                         target_gray = cv2.equalizeHist(target_gray)
#                         template_gray = cv2.equalizeHist(template_gray)
                
#                         # Apply Canny edge detection for robustness
#                         target_edges = cv2.Canny(target_gray, 50, 150)
#                         template_edges = cv2.Canny(template_gray, 50, 150)
                
#                         # Template matching
#                         res = cv2.matchTemplate(target_edges, template_edges, cv2.TM_CCOEFF_NORMED)
#                         _, max_val, _, max_loc = cv2.minMaxLoc(res)
                
#                         # Get template size
#                         h, w = template_gray.shape
                
#                         # Define bounding box of matched region
#                         top_left = max_loc
#                         bottom_right = (top_left[0] + w, top_left[1] + h)
                
#                         # Crop the region
#                         cropped = target[top_left[1]:bottom_right[1], top_left[0]:bottom_right[0]]
                        
#                         if cropped.size == 0:
#                             print(f"Empty cropped region for section {c}")
#                             c += 1
#                             j = k
#                             k += 400
#                             continue
                
#                         gray = cv2.cvtColor(cropped, cv2.COLOR_BGR2GRAY)
#                         blur = cv2.medianBlur(gray, 19)
#                         sharpen_kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
#                         sharpen = cv2.filter2D(blur, -1, sharpen_kernel)
                
#                         # Threshold and morph close
#                         thresh = cv2.threshold(sharpen, 105, 185, cv2.THRESH_BINARY_INV)[1]
#                         kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
#                         close = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=2)
                
#                         count = 0
#                         i = 50
#                         while i < min(220, close.shape[0] - 10):  # Don't exceed image height
#                             if np.sum(close[i:i+10,:]) > 60000:
#                                 i = i + 40
#                                 count += 1
#                             else:
#                                 i += 1
                                
#                         print(f'image--{c}')
#                         if count == 2:
#                             print('Both C and T are available')
#                         elif count == 1:
#                             print('Only C is available')
#                         elif count == 0:
#                             print('Invalid')
#                         else:
#                             print('Wrong Output')
                            
#                         l.extend([c, count])
#                         c += 1
#                         j = k
#                         k += 400
                    
#                     # Add results from this image to global result
#                     result.extend(l)
#                     print(f"Image {filename} processed successfully. Results: {l}")
                    
#                 except Exception as e:
#                     print(f"Error processing image {filename}: {e}")
                    
                    
#         print(f"All images processed. Final results: {result}")
#         return result
#         # Update BLE characteristic with results
#         # if device and result:
#         #     result_str = json.dumps(result)
#         #     print(f"Updating BLE characteristic with result: {result_str}")
#         #     try:
#         #         # Update characteristic using the correct bluezero method
#         #         #device.update_value(srv_id=1, chr_id=2, value=result_str.encode('utf-8'))
#         #         print("BLE characteristic updated successfully")
#         #     except Exception as e:
#         #         print(f"Error updating BLE characteristic: {e}")
#         # else:
#         #     print("No device provided or no results to update")
            
#     except Exception as e:
#         print(f"Error in process_image_data: {e}")
#         result = [{"error": str(e)}]
#         return result
        
#     finally:
#         # Clear folder after processing
#         print(f"Clearing image folder: {folder_path}")
#         clear_image_folder(folder_path)
        
#     return result

# def receive_image_from_slave(sock, slave_id, response_data):
#     """Receive image file from slave"""
#     try:
#         # Receive file size
#         size_data = sock.recv(1024).decode().strip()
#         file_size = int(size_data)
#         print(f"[MASTER] Expecting image of {file_size} bytes from Slave {slave_id}")
        
#         # Send acknowledgment
#         sock.send("READY".encode())
        
#         # Receive file data
#         received_data = b""
#         bytes_received = 0
        
#         while bytes_received < file_size:
#             chunk = sock.recv(min(4096, file_size - bytes_received))
#             if not chunk:
#                 break
#             received_data += chunk
#             bytes_received += len(chunk)
            
#             # Show progress for large files
#             if file_size > 100000:  # Show progress for files > 100KB
#                 progress = (bytes_received / file_size) * 100
#                 print(f"[MASTER] Receiving from Slave {slave_id}: {progress:.1f}%")
        
#         if bytes_received == file_size:
#             # Save the image
#             timestamp = int(time.time())
#             filename = f"master_received_slave{slave_id}_{timestamp}.jpg"
#             filepath = os.path.join(MASTER_IMAGE_DIR, filename)
            
#             with open(filepath, 'wb') as f:
#                 f.write(received_data)
            
#             print(f"[MASTER] Image saved from Slave {slave_id}: {filename}")
            
#             return {
#                 "success": True,
#                 "filepath": filepath,
#                 "filename": filename,
#                 "size": file_size
#             }
#         else:
#             print(f"[MASTER] Incomplete image received from Slave {slave_id}")
#             return {"success": False, "error": "Incomplete transfer"}
            
#     except Exception as e:
#         print(f"[MASTER] Error receiving image from Slave {slave_id}: {e}")
#         return {"success": False, "error": str(e)}

# def send_capture_command(slave_host, slave_id, receive_image=True):
#     """Send capture command to a slave and optionally receive the image"""
#     try:
#         print(f"[MASTER] Connecting to Slave {slave_id} at {slave_host}:{SLAVE_PORT}...")
        
#         # Create socket and connect
#         sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#         sock.settimeout(TIMEOUT)
#         sock.connect((slave_host, SLAVE_PORT))
        
#         print(f"[MASTER] Connected to Slave {slave_id}")
        
#         # Send capture command
#         command = {
#             "action": "capture",
#             "timestamp": time.time(),
#             "send_image": receive_image
#         }
#         message = json.dumps(command) + '\n'
#         sock.send(message.encode())
#         print(f"[MASTER] Sent capture command to Slave {slave_id}")
        
#         # Wait for response
#         response = sock.recv(1024).decode().strip()
#         response_data = json.loads(response)
        
#         print(f"[MASTER] Response from Slave {slave_id}: {response_data['message']}")
        
#         if response_data['status'] == 'success':
#             print(f"[MASTER] Slave {slave_id} successfully captured image")
            
#             # Receive image if requested and capture was successful
#             if receive_image:
#                 image_result = receive_image_from_slave(sock, slave_id, response_data)
#                 if image_result['success']:
#                     print(f"[MASTER] Image successfully received from Slave {slave_id}")
#                     return image_result
#                 else:
#                     print(f"[MASTER] Failed to receive image from Slave {slave_id}: {image_result.get('error')}")
#                     return image_result
#         else:
#             print(f"[MASTER] Slave {slave_id} failed to capture image: {response_data.get('error', 'Unknown error')}")
#             return {"success": False, "error": response_data.get('error', 'Unknown error')}
            
#     except socket.timeout:
#         print(f"[MASTER] Timeout waiting for Slave {slave_id}")
#         return {"success": False, "error": "Timeout"}
#     except ConnectionRefusedError:
#         print(f"[MASTER] Could not connect to Slave {slave_id} - service not running")
#         return {"success": False, "error": "Connection refused"}
#     except Exception as e:
#         print(f"[MASTER] Error communicating with Slave {slave_id}: {e}")
#         return {"success": False, "error": str(e)}
#     finally:
#         try:
#             sock.close()
#         except:
#             pass

# def send_capture_to_all_slaves(receive_images=True):
#     """Send capture command to all slaves simultaneously"""
#     threads = []
#     results = {}
    
#     def capture_with_result(slave_host, slave_id, receive_images):
#         """Wrapper to capture results from threads"""
#         result = send_capture_command(slave_host, slave_id, receive_images)
#         results[slave_id] = result
    
#     for slave_id, slave_host in SLAVE_HOSTS.items():
#         thread = threading.Thread(
#             target=capture_with_result, 
#             args=(slave_host, slave_id, receive_images)
#         )
#         threads.append(thread)
#         thread.start()
    
#     # Wait for all threads to complete
#     for thread in threads:
#         thread.join()
    
#     # Check if any images were successfully received
#     successful_transfers = [r for r in results.values() if r.get('success', False)]
    
#     print(f"[MASTER] Completed capture from all slaves. {len(successful_transfers)} successful transfers.")
    
#     # Process images if any were received successfully
#     if successful_transfers:
#         print("[MASTER] Starting image processing...")
#         # Add a small delay to ensure all files are written
#         time.sleep(1)
#         process_image_data(device=my_device, folder_path=MASTER_IMAGE_DIR)
#     else:
#         print("[MASTER] No images received successfully, skipping processing")

# if __name__ == "__main__":
#     print("[MASTER] Starting BLE WiFi Camera Controller")
#     print(f"[MASTER] Using Bluetooth adapter: {ADAPTER_ADDR}")

#     my_device.add_service(srv_id=1, uuid='12345678-1234-5678-1234-56789abcdef0', primary=True)
#     my_device.add_characteristic(
#         srv_id=1,
#         chr_id=1,
#         uuid='abcd1234-5678-4321-1234-fedcba987654',
#         value=f"master Ready".encode(),
#         notifying=True,
#         flags=['write', 'notify'],
#         write_callback=lambda value, options: write_callback(value, options)
#     )
#     my_device.add_characteristic(
#         srv_id=1,
#         chr_id=2,
#         uuid='abcd1234-5678-4321-1234-fedcba987655',
#         value=f"master Ready".encode(),
#         notifying=True,
#         flags=['read', 'notify'],
#         write_callback=lambda value, options: write_callback(value, options)
#     )
#     print(f"Master BLE advertising started...")
#     my_device.publish()



# master_wifi_controller.py
import socket
import time
import threading
import json
import os
from bluezero import peripheral
import cv2
import numpy as np

folder_path = '/home/rpiez/received_images'

def clear_image_folder(folder_path='/home/rpiez/received_images'):
    """Clear all images in the received images folder"""
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    
    # Remove all files in the folder
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if os.path.isfile(file_path):
            os.remove(file_path)

clear_image_folder()  # Clear the image folder at startup

ADAPTER_ADDR = 'B8:27:EB:11:A5:AA'  # Replace with your Pi's Bluetooth MAC
my_device = peripheral.Peripheral(adapter_address=ADAPTER_ADDR, local_name=f'master')

result = "master Ready"  # Initialize with default value
processing_complete = False  # Flag to track processing status

def write_callback(value, options):
    global processing_complete
    command = value.decode()
    print(f"Received command: {command}")
    if command.strip() == "capture":
        processing_complete = False  # Reset flag
        threading.Thread(target=send_capture_to_all_slaves).start()

def read_callback(options):
    """Callback for read operations on characteristic 2"""
    global result
    print(f"Read callback triggered, returning: {result}")
    return result.encode('utf-8')

# Replace with your actual slave Pi hostnames
SLAVE_HOSTS = {
    1: 'slcam01.local',
    2: 'slcam02.local', 
    3: 'slcam03.local',
    4: 'slcam04.local',
    5: 'slcam05.local',
    # Add more slaves as needed
}   

SLAVE_PORT = 8888  # Port that slaves will listen on
TIMEOUT = 30  # Timeout in seconds
MASTER_IMAGE_DIR = "/home/rpiez/received_images"  # Directory to save received images

# Create master image directory
os.makedirs(MASTER_IMAGE_DIR, exist_ok=True)

def update_ble_result(new_result):
    """Update the global result and notify BLE clients"""
    global result, processing_complete
    result = new_result
    processing_complete = True
    
    try:
        # Update the characteristic value
        my_device.update_characteristic_value(1, 2, result.encode('utf-8'))
        print(f"BLE characteristic updated with result: {result}")
    except Exception as e:
        print(f"Error updating BLE characteristic: {e}")

def process_image_data(device=None, folder_path='/home/rpiez/received_images'):
    """Process images and update BLE characteristic with results"""
    process_results = []
    
    try:
        print(f"Processing images in folder: {folder_path}")
        
        if not os.path.exists(folder_path):
            print(f"Folder {folder_path} does not exist")
            update_ble_result("Error: Folder not found")
            return []
            
        image_files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
        
        if not image_files:
            print("No image files found to process")
            update_ble_result("No images to process")
            return []
            
        print(f"Found {len(image_files)} image files to process")
        
        for filename in image_files:
            file_path = os.path.join(folder_path, filename)
            if os.path.isfile(file_path):
                try:
                    print(f"Processing image: {filename}")
                    target_path = file_path
                    template_path = '/home/rpiez/tcp/template_1.jpg'
                    
                    if not os.path.exists(template_path):
                        print(f"Template file not found: {template_path}")
                        continue
                        
                    j = 0
                    k = 400
                    c = 1
                    image_results = []
                    
                    # Read the full target image first to check dimensions
                    full_target = cv2.imread(target_path)
                    if full_target is None:
                        print(f"Could not read image: {target_path}")
                        continue
                        
                    image_width = full_target.shape[1]
                    print(f"Image width: {image_width}")
                    
                    while k <= min(800, image_width):
                        target = cv2.imread(target_path)[:, j:k]
                        template = cv2.imread(template_path)
                        
                        if target is None or template is None:
                            print(f"Could not read target or template image")
                            break
                
                        # Convert to grayscale
                        target_gray = cv2.cvtColor(target, cv2.COLOR_BGR2GRAY)
                        template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
                
                        # Enhance contrast with histogram equalization
                        target_gray = cv2.equalizeHist(target_gray)
                        template_gray = cv2.equalizeHist(template_gray)
                
                        # Apply Canny edge detection for robustness
                        target_edges = cv2.Canny(target_gray, 50, 150)
                        template_edges = cv2.Canny(template_gray, 50, 150)
                
                        # Template matching
                        res = cv2.matchTemplate(target_edges, template_edges, cv2.TM_CCOEFF_NORMED)
                        _, max_val, _, max_loc = cv2.minMaxLoc(res)
                
                        # Get template size
                        h, w = template_gray.shape
                
                        # Define bounding box of matched region
                        top_left = max_loc
                        bottom_right = (top_left[0] + w, top_left[1] + h)
                
                        # Crop the region
                        cropped = target[top_left[1]:bottom_right[1], top_left[0]:bottom_right[0]]
                        
                        if cropped.size == 0:
                            print(f"Empty cropped region for section {c}")
                            c += 1
                            j = k
                            k += 400
                            continue
                
                        gray = cv2.cvtColor(cropped, cv2.COLOR_BGR2GRAY)
                        blur = cv2.medianBlur(gray, 19)
                        sharpen_kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
                        sharpen = cv2.filter2D(blur, -1, sharpen_kernel)
                
                        # Threshold and morph close
                        thresh = cv2.threshold(sharpen, 105, 185, cv2.THRESH_BINARY_INV)[1]
                        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
                        close = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=2)
                
                        count = 0
                        i = 50
                        while i < min(220, close.shape[0] - 10):
                            if np.sum(close[i:i+10,:]) > 60000:
                                i = i + 40
                                count += 1
                            else:
                                i += 1
                                
                        print(f'image--{c}')
                        status = ""
                        if count == 2:
                            status = 'Both C and T available'
                            print('Both C and T are available')
                        elif count == 1:
                            status = 'Only C available'
                            print('Only C is available')
                        elif count == 0:
                            status = 'Invalid'
                            print('Invalid')
                        else:
                            status = 'Wrong Output'
                            print('Wrong Output')
                            
                        image_results.extend([c, count])
                        c += 1
                        j = k
                        k += 400
                    
                    # Add results from this image to process results
                    process_results.append(image_results)
                    print(f"Image {filename} processed successfully. Results: {image_results}")
                    
                except Exception as e:
                    print(f"Error processing image {filename}: {e}")
                    
        # Format results as JSON string
        if process_results:
            result_str = json.dumps({"results": process_results, "status": "complete"})
            print(f"All images processed. Final results: {process_results}")
            update_ble_result(result_str)
        else:
            update_ble_result("No valid results")
            
    except Exception as e:
        print(f"Error in process_image_data: {e}")
        error_result = json.dumps({"error": str(e), "status": "error"})
        update_ble_result(error_result)
        
    finally:
        # Clear folder after processing
        print(f"Clearing image folder: {folder_path}")
        clear_image_folder(folder_path)
        
    return process_results

def receive_image_from_slave(sock, slave_id, response_data):
    """Receive image file from slave"""
    try:
        # Receive file size
        size_data = sock.recv(1024).decode().strip()
        file_size = int(size_data)
        print(f"[MASTER] Expecting image of {file_size} bytes from Slave {slave_id}")
        
        # Send acknowledgment
        sock.send("READY".encode())
        
        # Receive file data
        received_data = b""
        bytes_received = 0
        
        while bytes_received < file_size:
            chunk = sock.recv(min(4096, file_size - bytes_received))
            if not chunk:
                break
            received_data += chunk
            bytes_received += len(chunk)
            
            # Show progress for large files
            if file_size > 100000:
                progress = (bytes_received / file_size) * 100
                print(f"[MASTER] Receiving from Slave {slave_id}: {progress:.1f}%")
        
        if bytes_received == file_size:
            # Save the image
            timestamp = int(time.time())
            filename = f"master_received_slave{slave_id}_{timestamp}.jpg"
            filepath = os.path.join(MASTER_IMAGE_DIR, filename)
            
            with open(filepath, 'wb') as f:
                f.write(received_data)
            
            print(f"[MASTER] Image saved from Slave {slave_id}: {filename}")
            
            return {
                "success": True,
                "filepath": filepath,
                "filename": filename,
                "size": file_size
            }
        else:
            print(f"[MASTER] Incomplete image received from Slave {slave_id}")
            return {"success": False, "error": "Incomplete transfer"}
            
    except Exception as e:
        print(f"[MASTER] Error receiving image from Slave {slave_id}: {e}")
        return {"success": False, "error": str(e)}

def send_capture_command(slave_host, slave_id, receive_image=True):
    """Send capture command to a slave and optionally receive the image"""
    try:
        print(f"[MASTER] Connecting to Slave {slave_id} at {slave_host}:{SLAVE_PORT}...")
        
        # Create socket and connect
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(TIMEOUT)
        sock.connect((slave_host, SLAVE_PORT))
        
        print(f"[MASTER] Connected to Slave {slave_id}")
        
        # Send capture command
        command = {
            "action": "capture",
            "timestamp": time.time(),
            "send_image": receive_image
        }
        message = json.dumps(command) + '\n'
        sock.send(message.encode())
        print(f"[MASTER] Sent capture command to Slave {slave_id}")
        
        # Wait for response
        response = sock.recv(1024).decode().strip()
        response_data = json.loads(response)
        
        print(f"[MASTER] Response from Slave {slave_id}: {response_data['message']}")
        
        if response_data['status'] == 'success':
            print(f"[MASTER] Slave {slave_id} successfully captured image")
            
            # Receive image if requested and capture was successful
            if receive_image:
                image_result = receive_image_from_slave(sock, slave_id, response_data)
                if image_result['success']:
                    print(f"[MASTER] Image successfully received from Slave {slave_id}")
                    return image_result
                else:
                    print(f"[MASTER] Failed to receive image from Slave {slave_id}: {image_result.get('error')}")
                    return image_result
        else:
            print(f"[MASTER] Slave {slave_id} failed to capture image: {response_data.get('error', 'Unknown error')}")
            return {"success": False, "error": response_data.get('error', 'Unknown error')}
            
    except socket.timeout:
        print(f"[MASTER] Timeout waiting for Slave {slave_id}")
        return {"success": False, "error": "Timeout"}
    except ConnectionRefusedError:
        print(f"[MASTER] Could not connect to Slave {slave_id} - service not running")
        return {"success": False, "error": "Connection refused"}
    except Exception as e:
        print(f"[MASTER] Error communicating with Slave {slave_id}: {e}")
        return {"success": False, "error": str(e)}
    finally:
        try:
            sock.close()
        except:
            pass

def send_capture_to_all_slaves(receive_images=True):
    """Send capture command to all slaves simultaneously"""
    threads = []
    results = {}
    
    # Update BLE to indicate processing started
    update_ble_result("Processing started...")
    
    def capture_with_result(slave_host, slave_id, receive_images):
        """Wrapper to capture results from threads"""
        result = send_capture_command(slave_host, slave_id, receive_images)
        results[slave_id] = result
    
    for slave_id, slave_host in SLAVE_HOSTS.items():
        thread = threading.Thread(
            target=capture_with_result, 
            args=(slave_host, slave_id, receive_images)
        )
        threads.append(thread)
        thread.start()
    
    # Wait for all threads to complete
    for thread in threads:
        thread.join()
    
    # Check if any images were successfully received
    successful_transfers = [r for r in results.values() if r.get('success', False)]
    
    print(f"[MASTER] Completed capture from all slaves. {len(successful_transfers)} successful transfers.")
    
    # Process images if any were received successfully
    if successful_transfers:
        print("[MASTER] Starting image processing...")
        update_ble_result("Images received, processing...")
        # Add a small delay to ensure all files are written
        time.sleep(1)
        process_image_data(device=my_device, folder_path=MASTER_IMAGE_DIR)
    else:
        print("[MASTER] No images received successfully, skipping processing")
        update_ble_result("No images received")

if __name__ == "__main__":
    print("[MASTER] Starting BLE WiFi Camera Controller")
    print(f"[MASTER] Using Bluetooth adapter: {ADAPTER_ADDR}")

    my_device.add_service(srv_id=1, uuid='12345678-1234-5678-1234-56789abcdef0', primary=True)
    
    # Characteristic 1: Write only (for commands)
    my_device.add_characteristic(
        srv_id=1,
        chr_id=1,
        uuid='abcd1234-5678-4321-1234-fedcba987654',
        value=f"master Ready".encode(),
        notifying=False,
        flags=['write'],
        write_callback=write_callback
    )
    
    # Characteristic 2: Read and Notify (for results)
    my_device.add_characteristic(
        srv_id=1,
        chr_id=2,
        uuid='abcd1234-5678-4321-1234-fedcba987655',
        value=result.encode(),
        notifying=True,
        flags=['read', 'notify'],
        read_callback=read_callback
    )
    
    print(f"Master BLE advertising started...")
    my_device.publish()
