import time
import dbus
import json
import dbus.service
import dbus.mainloop.glib
from advertisement import Advertisement
from service import Application, Service, Characteristic, Descriptor
from gi.repository import GLib
from camer_module_v4_3 import CameraModule
import numpy as np
from rgb_coef_module_json import RGBModule
from pos_urine import pos
from PIL import Image

start_time = time.time()

# BLE Agent Configuration
AGENT_PATH = "/test/agent"
AGENT_INTERFACE = "org.bluez.Agent1"
GATT_CHRC_IFACE = "org.bluez.GattCharacteristic1"
NOTIFY_TIMEOUT = 100
PACKET_SIZE = 200

class NoPairAgent(dbus.service.Object):
    def __init__(self, bus):
        super().__init__(bus, AGENT_PATH)

    @dbus.service.method(AGENT_INTERFACE, in_signature="", out_signature="")
    def Release(self):
        print("NoPairAgent released")

    @dbus.service.method(AGENT_INTERFACE, in_signature="o", out_signature="")
    def RequestAuthorization(self, device):
        print("Authorization requested for", device)

    @dbus.service.method(AGENT_INTERFACE, in_signature="os", out_signature="")
    def AuthorizeService(self, device, uuid):
        print(f"AuthorizeService for {device}, uuid {uuid}")
        return

    @dbus.service.method(AGENT_INTERFACE, in_signature="o", out_signature="s")
    def RequestPinCode(self, device):
        raise dbus.exceptions.DBusException("org.bluez.Error.Rejected", "No PIN")

    @dbus.service.method(AGENT_INTERFACE, in_signature="o", out_signature="u")
    def RequestPasskey(self, device):
        raise dbus.exceptions.DBusException("org.bluez.Error.Rejected", "No Passkey")

    @dbus.service.method(AGENT_INTERFACE, in_signature="ou", out_signature="")
    def RequestConfirmation(self, device, passkey):
        raise dbus.exceptions.DBusException("org.bluez.Error.Rejected", "No Confirmation")

    @dbus.service.method(AGENT_INTERFACE, in_signature="", out_signature="")
    def Cancel(self):
        print("Pairing cancelled.")

def register_no_pair_agent():
    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
    bus = dbus.SystemBus()
    agent = NoPairAgent(bus)
    
    manager = dbus.Interface(
        bus.get_object("org.bluez", "/org/bluez"),
        "org.bluez.AgentManager1"
    )
    manager.RegisterAgent(AGENT_PATH, "NoInputNoOutput")
    manager.RequestDefaultAgent(AGENT_PATH)
    print("🛡️  NoPairAgent registered with BlueZ.")

# Connection manager removed - using simple authorization approach

class StateManager:
    def __init__(self):
        self.device_states = {}
        self.last_command = None
        self.last_device = None
        self.persistent_file = 'device_state.json'
        self.load_state()

    def save_state(self):
        try:
            with open(self.persistent_file, 'w') as f:
                json.dump({
                    'device_states': self.device_states,
                    'last_command': self.last_command,
                    'last_device': self.last_device
                }, f)
        except Exception as e:
            print(f"Error saving state: {e}")

    def load_state(self):
        try:
            with open(self.persistent_file, 'r') as f:
                saved_data = json.load(f)
                self.device_states = saved_data.get('device_states', {})
                self.last_command = saved_data.get('last_command')
                self.last_device = saved_data.get('last_device')
        except FileNotFoundError:
            self.device_states = {}
            self.last_command = None
            self.last_device = None
        except Exception as e:
            print(f"Error loading state: {e}")

    def update_device_state(self, device_address, command=None):
        if device_address not in self.device_states:
            self.device_states[device_address] = {}
        
        if command:
            self.device_states[device_address]['last_command'] = command
            self.last_command = command
            self.last_device = device_address
        
        self.save_state()

# Initialize global managers
# connection_manager = ConnectionManager()  # Removed - not properly integrated
state_manager = StateManager()

# Initialize hardware modules
pos_v = pos()
cam = CameraModule()
rgb = RGBModule()

class BLEAdvertisement(Advertisement):
    def __init__(self, index):
        Advertisement.__init__(self, index, "peripheral")
        self.add_local_name("EF0002")
        self.include_tx_power = True


class ImageCharacteristic(Characteristic):
    CHARACTERISTIC_UUID = "4d6783c9-db8c-4cdb-bc4a-37e04e363809"
    EOF_MARKER = bytes([0xFF, 0xD9, 0xFF, 0xEE, 0xEE])

    def __init__(self, service):
        self.notifying = False
        self.start_time = None
        self.current_packet = 0
        self.total_packets = 0
        self.data_buffer = None
        self.data_prepared = False
        Characteristic.__init__(
            self, self.CHARACTERISTIC_UUID,
            ["notify", "read"], service)
        self.add_descriptor(ImageDescriptor(self))

    def prepare_data(self):
        """Capture image and prepare it for transmission, but don't start sending"""
        try:
            if self.notifying:
                print("Already in a transfer session. Cannot prepare new data.")
                return False
                
            print("Capturing image...")
            image_data = cam.capture_image(apply_color_correction=True, byte_image=True)
            print(image_data)
            # send_image = Image.fromarray(image_data)
            # send_image.save('send_image.jpeg')
            
            if image_data is None:
                print("Failed to capture image")
                return False

            # # Convert image to correct format for JPEG
            # try:
            #     if isinstance(image_data, np.ndarray):
            #         # If the image is in RGB format, convert to BGR
            #         if image_data.shape[-1] == 3:
            #             image_data = image_data[..., ::-1]

            #     # Convert to bytes if not already
            #     if not isinstance(image_data, bytes):
            #         with io.BytesIO() as bio:
            #             imageio.imwrite(bio, image_data, format='jpg')
            #             self.data_buffer = bio.getvalue()
            #     else:
            self.data_buffer = image_data

            print(f"Image captured, size: {len(self.data_buffer)} bytes")
            self.total_packets = (len(self.data_buffer) + PACKET_SIZE-1) // PACKET_SIZE
            self.data_prepared = True
            
            print(f"Data prepared: {self.total_packets} packets ready for transmission")
            return True

        except Exception as e:
            print(f"Error preparing image data: {e}")
            self.data_prepared = False
            return False

    def get_next_packet(self):
        if self.current_packet >= self.total_packets:
            return None

        start_idx = self.current_packet * PACKET_SIZE
        end_idx = min(start_idx + PACKET_SIZE, len(self.data_buffer))
        #packet_header = self.current_packet.to_bytes(4, byteorder='big')
        data_slice = self.data_buffer[start_idx:end_idx]
        packet = data_slice

        self.current_packet += 1
        print(f"Sending packet {self.current_packet}/{self.total_packets}")
        return packet

    def clear_buffer(self):
        """Clear the data buffer after transmission"""
        self.data_buffer = None
        self.data_prepared = False
        self.current_packet = 0
        self.total_packets = 0
        print("Image buffer cleared")

    def ReadValue(self, options):
        if not self.data_prepared or self.data_buffer is None:
            value = []
            msg = "No image data available"
            for c in msg:
                value.append(dbus.Byte(c.encode()))
            return value
        
        # Return information about prepared image data
        value = []
        msg = f"Image data prepared: {len(self.data_buffer)} bytes, {self.total_packets} packets"
        for c in msg[:20]:  # Limit to first 20 chars to avoid overflow
            value.append(dbus.Byte(c.encode()))
        return value
        
    def StartNotify(self, options=None):
        if options:
            device_address = options.get('device', 'unknown')
            print(f"🔔 Notifications started by: {device_address}")

        if self.notifying:
            print("Already notifying")
            return

        if not self.data_prepared or self.data_buffer is None:
            print("No data prepared for transmission. Send 'sd' command first.")
            return

        self.notifying = True
        self.start_time = time.time()

        # Send the header with metadata about the image
        header_bytes = (
            len(self.data_buffer).to_bytes(4, byteorder='big') +
            self.total_packets.to_bytes(4, byteorder='big') +
            PACKET_SIZE.to_bytes(2, byteorder='big')
        )

        value = [dbus.Byte(b) for b in header_bytes]
        self.PropertiesChanged(GATT_CHRC_IFACE, {"Value": value}, [])

        self.current_packet = 0
        GLib.timeout_add(NOTIFY_TIMEOUT, self.send_next_packet)

    def send_next_packet(self):
        if not self.notifying:
            return False

        packet = self.get_next_packet()
        if packet is None:
            # Send EOF marker
            value = [dbus.Byte(b) for b in self.EOF_MARKER]
            self.PropertiesChanged(GATT_CHRC_IFACE, {"Value": value}, [])

            elapsed_time = time.time() - self.start_time
            transfer_speed = len(self.data_buffer) / elapsed_time / 1024
            print(f"Transfer completed in {elapsed_time:.2f} seconds")
            print(f"Average speed: {transfer_speed:.2f} KB/s")

            cam.close()
            self.notifying = False
            self.clear_buffer()  # Clear the buffer after successful transmission
            return False

        value = [dbus.Byte(b) for b in packet]
        self.PropertiesChanged(GATT_CHRC_IFACE, {"Value": value}, [])
        return True

class ImageDescriptor(Descriptor):
    DESCRIPTOR_UUID = "2901"
    DESCRIPTOR_VALUE = "Image Data"

    def __init__(self, characteristic):
        Descriptor.__init__(
            self, self.DESCRIPTOR_UUID,
            ["read"],
            characteristic)

    def ReadValue(self, options):
        value = []
        for c in self.DESCRIPTOR_VALUE:
            value.append(dbus.Byte(c.encode()))
        return value

class PositionCharacteristic(Characteristic):
    CHARACTERISTIC_UUID = "c2d2dfec-3ca7-438e-89ed-4742f1e6526a"

    def __init__(self, service):
        self.data_prepared = False
        self.position_result = None
        self.battery_level = None
        self.rgb_data = None
        Characteristic.__init__(self, self.CHARACTERISTIC_UUID, ["notify", "read"], service)
        self.add_descriptor(PositionDescriptor(self))
    
    def update_coef(self, coef):
        rgb.update_coef(coef)
        print(f"RGB coefficient updated to: {coef}")
    
    def prepare_rgb_data(self):
        """Capture RGB data"""
        if self.rgb_data is not None:
            print("RGB data already prepared.")
            return True
        
        print("1st position verification start in 20 seconds...")
        time.sleep(19)
        img = cam.capture_image(apply_color_correction=True, byte_image=False)
        self.position_result = pos_v.ver_pos(img)
        print(f"1st Position verification result: {self.position_result}")
        
        # Send position result to client
        value = [dbus.Byte(b) for b in self.position_result.encode('utf-8')]       
        self.PropertiesChanged(GATT_CHRC_IFACE, {"Value": value}, [])
        
        if self.position_result == "true":
            time.sleep(40)
            print("Position verified. Waiting before RGB capture...")
            img_prid_1 = cam.capture_image(apply_color_correction=True, byte_image=False)
            self.rgb_data = rgb.get_rgb_values(img_prid_1)
            img_characteristic = self.service.get_characteristic("4d6783c9-db8c-4cdb-bc4a-37e04e363809")
            img_characteristic.prepare_data()
        elif self.position_result == "false":
            time.sleep(20)
            img_prid_2 = cam.capture_image(apply_color_correction=True, byte_image=False)
            self.position_result = pos_v.ver_pos(img_prid_2)
            print(f"2nd Position verification result: {self.position_result}")
            
            value = [dbus.Byte(b) for b in self.position_result.encode('utf-8')]       
            self.PropertiesChanged(GATT_CHRC_IFACE, {"Value": value}, [])
            
            time.sleep(20)
            print("Position verified. RGB capture starting...")
            img_prid = cam.capture_image(apply_color_correction=True, byte_image=False)
            self.rgb_data = rgb.get_rgb_values(img_prid)
            
            img_characteristic = self.service.get_characteristic("4d6783c9-db8c-4cdb-bc4a-37e04e363809")
            img_characteristic.prepare_data()
        
        if self.rgb_data is None:
            print("Failed to capture RGB data")
            return False
        
        print(f"RGB data captured: {self.rgb_data}")
        self.data_prepared = True
        return True
    
    def prepare_battery_data(self):
        """Capture battery data"""
        if self.battery_level is not None:
            print("Battery data already prepared.")
            return True
        
        print("Capturing battery data...")
        self.battery_level = 1.81  # Hardcoded value - replace with actual ADC reading
        
        if self.battery_level is None:
            print("Failed to capture battery level")
            return False
        
        print(f"Battery level: {self.battery_level}")
        self.data_prepared = True
        return True
    
    def prepare_position_data(self):
        """Capture image and prepare position verification data"""
        if self.data_prepared:
            print("Position data already prepared.")
            return True
            
        print("Capturing image for position verification...")
        img = cam.capture_image(apply_color_correction=True, byte_image=False)
        print(f"Image shape: {img.shape}")
        
        # Save debug image
        debug_img = Image.fromarray(img)
        debug_img.save("debug_position_capture.jpeg")
        
        self.position_result = pos_v.ver_pos(img)
        print(f"Position verification result: {self.position_result}")
        
        self.data_prepared = True
        print("Position data prepared and ready for transmission")
        return True
    
    def clear_data(self):
        """Clear the prepared data"""
        self.position_result = None
        self.battery_level = None
        self.rgb_data = None
        self.data_prepared = False
        print("Data cleared")
    
    def ReadValue(self, options):
        value = []
        
        if not self.data_prepared:
            if self.position_result is None:
                msg = "Position data not prepared. Send 'pos' command first."
            elif self.battery_level is None:
                msg = "Battery data not prepared. Send 'bat' command first."
            elif self.rgb_data is None:
                msg = "RGB data not prepared. Send 'sd' command first."
        elif self.position_result is not None:
            msg = f"Position data ready: {self.position_result[:20]}..."
        elif self.battery_level is not None:
            msg = f"Battery level: {self.battery_level}"
        elif self.rgb_data is not None:
            msg = "RGB data ready"
        
        for c in msg:   
            value.append(dbus.Byte(c.encode()))
        return value
    
    def StartNotify(self, options=None):
        if options:
            device_address = options.get('device', 'unknown')
            print(f"🔔 Notifications started by: {device_address}")
            
        # Send appropriate data based on what's available
        if self.rgb_data is not None:
            print("Sending RGB data...")
            value = [dbus.Byte(b) for b in str(self.rgb_data).encode('utf-8')]
            
            packets = [value[i:i + 150] for i in range(0, len(value), 150)]
            print(f"Sending {len(packets)} RGB data packets...")
            
            for pkt in packets:
                self.PropertiesChanged(GATT_CHRC_IFACE, {"Value": pkt}, [])
                time.sleep(0.1)
            
            # Send EOF marker
            EOF_MARKER = bytes([0xFF, 0xD9, 0xFF, 0xEE, 0xEE])
            value = [dbus.Byte(b) for b in EOF_MARKER]
            self.PropertiesChanged(GATT_CHRC_IFACE, {"Value": value}, [])
            print("EOF marker sent for RGB data")
            
        elif self.position_result is not None:
            print("Sending position verification result...")
            value = [dbus.Byte(b) for b in self.position_result.encode('utf-8')]       
            self.PropertiesChanged(GATT_CHRC_IFACE, {"Value": value}, [])
            
        elif self.battery_level is not None:
            print("Sending battery level...")
            value = [dbus.Byte(b) for b in str(self.battery_level).encode('utf-8')]       
            self.PropertiesChanged(GATT_CHRC_IFACE, {"Value": value}, [])
        else:
            print("No data prepared to send.")
            return
        
        # Clear data after sending
        print("Clearing data after sending")
        self.clear_data()

class PositionDescriptor(Descriptor):
    DESCRIPTOR_UUID = "2901"
    DESCRIPTOR_VALUE = "Position Verification"

    def __init__(self, characteristic):
        Descriptor.__init__(self, self.DESCRIPTOR_UUID, ["read"], characteristic)

    def ReadValue(self, options):
        value = []
        for c in self.DESCRIPTOR_VALUE:
            value.append(dbus.Byte(c.encode()))
        return value

class UnitCharacteristic(Characteristic):
    CHARACTERISTIC_UUID = "c1e53625-3fdd-4567-8105-2e6e962f2a4e"

    def __init__(self, service):
        Characteristic.__init__(self, self.CHARACTERISTIC_UUID, ["notify", "write"], service)
        self.add_descriptor(UnitDescriptor(self))
        self.awaiting_coef = False
        self.collected_json_data = ""

    def WriteValue(self, value, options):
        device_address = options.get('device', 'unknown')
        print(f"📡 Device connected: {device_address}")
        
        try:
            device_address = options.get('device', 'unknown')
            
            if isinstance(value, dbus.Array):
                value_bytes = bytes(value)
            else:
                value_bytes = bytes(value)

            cmd = value_bytes.decode('utf-8')
            print(f"Received command: {cmd}")
            
            # Simplified - removed unused connection manager check
            
            # Update command in state
            state_manager.update_device_state(device_address, cmd)
            
            if self.awaiting_coef:
                if cmd == "etx":
                    print("Coefficient data collection complete. Processing...")
                    pos_characteristic = self.service.get_characteristic("c2d2dfec-3ca7-438e-89ed-4742f1e6526a")
                    if pos_characteristic:
                        pos_characteristic.update_coef(self.collected_json_data)
                        print("Coefficient updated successfully")
                    else:
                        print("Position characteristic not found")
                    
                    # Reset collection state
                    self.awaiting_coef = False
                    self.collected_json_data = ""
                    return
                else:
                    print(f"Received coefficient data chunk: {cmd[:20]}...")
                    self.collected_json_data += cmd
                    return
            
            # Handle commands
            if cmd == 'update-coef':
                self.awaiting_coef = True
                self.collected_json_data = ""
                print("Waiting for coefficient data chunks...")
                return
            
            pos_characteristic = self.service.get_characteristic("c2d2dfec-3ca7-438e-89ed-4742f1e6526a")
            if not pos_characteristic:
                print("Position characteristic not found")
                return
            
            if cmd == 'bat':
                success = pos_characteristic.prepare_battery_data()
                print("Battery data prepared successfully" if success else "Failed to prepare battery data")
            elif cmd == 'sd':
                success = pos_characteristic.prepare_rgb_data()
                print("RGB data prepared successfully" if success else "Failed to prepare RGB data")
            elif cmd == 'pos':
                success = pos_characteristic.prepare_position_data()
                print("Position data prepared successfully" if success else "Failed to prepare position data")

        except Exception as e:
            print(f"Error processing command: {e}")

    def ReadValue(self, options):
        # Simplified - removed unused connection manager check
        value = []
        val = "Ready"
        for c in val:
            value.append(dbus.Byte(c.encode()))
        return value

class UnitDescriptor(Descriptor):
    DESCRIPTOR_UUID = "2901"
    DESCRIPTOR_VALUE = "Command Control"

    def __init__(self, characteristic):
        Descriptor.__init__(self, self.DESCRIPTOR_UUID, ["read"], characteristic)

    def ReadValue(self, options):
        value = []
        for c in self.DESCRIPTOR_VALUE:
            value.append(dbus.Byte(c.encode()))
        return value

class DeviceService(Service):
    SERVICE_UUID = "90bbc477-9014-4b62-b968-556a2ee913d5"

    def __init__(self, index):
        Service.__init__(self, index, self.SERVICE_UUID, True)
        self.characteristics = []
        
        position_char = PositionCharacteristic(self)
        unit_char = UnitCharacteristic(self)
        image_char = ImageCharacteristic(self)
        
        self.add_characteristic(position_char)
        self.add_characteristic(unit_char)
        self.add_characteristic(image_char)
        
        self.characteristics = [position_char, unit_char,image_char]
    
    def get_characteristic(self, uuid):
        for char in self.characteristics:
            if getattr(char, 'CHARACTERISTIC_UUID', None) == uuid:
                return char
        return None

def main():
    register_no_pair_agent()
    
    app = Application()
    app.add_service(DeviceService(0))
    app.register()

    adv = BLEAdvertisement(0)
    adv.register()

    try:
        app.run()
    except KeyboardInterrupt:
        app.quit()

if __name__ == '__main__':
    main()