# ### PH Model value ####
# coef_ph = [-0.01669591,  0.01048125,  0.00598256]
# int_ph = 7.401240358711474

# ### SG Model value
# coef_sg = [ 0.000272521, -0.000176152 , -0.000095644]
# int_sg = 1.0088557086373107

# #### WBC Model Value
# coef_wbc = [[-0.03815591,  0.05386747, -0.0246107 ],
#         [ 0.00357726,  0.00422193,  0.00470766],
#         [-0.00307664, -0.00854442,  0.01483404],
#         [ 0.03765529, -0.04954497,  0.00506899]]
# int_wbc = [ 2.54647769, -2.72594539, -1.46758575, -0.35294655]

# #### Blood model value ###
# coef_bld = [[ 1.84091545e-02, -9.05497631e-03, -1.05015099e-02],
#         [-6.61860835e-04, -1.42805455e-03,  2.63515763e-06],
#         [-1.77173017e-02,  2.54657313e-02, -5.80570617e-03],
#         [-2.99919492e-05, -1.49827005e-02,  1.63045809e-02]]
# int_bld = [-0.02392194, -0.63946459, -1.38116573,  0.04455225]

# #### protien model value ####
# coef_pro = [-0.02039438,  0.03994628, -0.01476654]
# int_pro = -2.29246074

# #### ketone model value ###
# coef_ket = [[-0.01585195,  0.0332431 , -0.02404733],
#         [ 0.00505722, -0.01109821,  0.02102749],
#         [ 0.01477388,  0.00202157, -0.02025834],
#         [-0.00052356, -0.0178988 ,  0.02210266],
#         [-0.00345559, -0.00626766,  0.00117552]]
# int_ket = [ 2.29443228, -3.28672713, -0.73855819, -1.60157854,  0.33243157]

# ### UroBilogen Model Value ###
# coef_uro = [[-0.01859939,  0.02432802, -0.01992753],
#         [ 0.00403878,  0.00426953,  0.0036268 ],
#         [ 0.00220427, -0.00328584,  0.00690769],
#         [ 0.00352284, -0.02117326,  0.01355669],
#         [ 0.0088335 , -0.00413844, -0.00416365]]
# int_uro = [ 3.30616918, -2.70409339, -1.79724573, -0.48496784, -1.31986221]

# ### Bilirubn model value ###
# coef_bil  = [[-0.0357276 ,  0.05556531, -0.0179633 ],
#         [ 0.00961668, -0.04157228,  0.03038141],
#         [ 0.02611092, -0.01399303, -0.0124181 ]]
# int_bil = [1.17021755, -0.47121088, -1.69900666]

# ### Nitrate model value ###
# coef_nit = [ 0.00965404, -0.04093634,  0.03843068]
# int_nit = -1.89240232

# coef_glu = [[-0.00767076, -0.0140941 ,  0.02366067],
#         [-0.01032577,  0.01827972, -0.0059402 ],
#         [-0.001948  ,  0.01085383, -0.00529741],
#         [-0.01656382,  0.02406091, -0.01489887],
#         [ 0.03313375, -0.02895744,  0.01499448],
#         [ 0.00337461, -0.01014291, -0.01251868]]
# int_glu = [-0.36793401, -1.214661  , -1.10499888, -0.21980869, -2.29280307,
#          1.20020565]

# # def predict(coef, intercept,rgb_value):
# #     val = 0
# #     for i in range(len(coef)):
# #         val+=rgb_value[i]*coef[i]
# #     val = val+intercept
# #     return val

# # def given_arr(coef,intercept,rgb_value):
# #     arr= []
# #     for i in range(len(coef)):
# #         val1 = 0
# #         for j in range(len(coef[i])):
# #             val1 += coef[i][j]*rgb_value[j]
# #         val1+=intercept[i]
# #         arr.append(val1)
# #     return arr
    
    
# # def predict_wb(coef,intercept,rgb_value):
# #     arr = given_arr(coef,intercept,rgb_value)
# #     max_1 = max(arr)
# #     indx1= arr.index(max_1)
# #     if indx1==0:
# #         pred = 0
# #     elif indx1==1:
# #         pred=25
# #     elif indx1==2:
# #         pred=75
# #     elif indx1 ==3:
# #         pred=500
# #     return pred

# # def predict_blood(coef,intercept,rgb_value):
# #     arr = given_arr(coef,intercept,rgb_value)
# #     max_1 = max(arr)
# #     indx1= arr.index(max_1)
# #     if indx1==0:
# #         pred = 0
# #     elif indx1==1:
# #         pred=10
# #     elif indx1==2:
# #         pred=50
# #     elif indx1==3:
# #         pred=250
# #     return pred

# # def predict_pro_nit(coef,intercept,rgb_value):
# #     val = predict(coef,intercept,rgb_value)
# #     if val>0:
# #         pred =1
# #     else:
# #         pred=0
# #     return pred

# # def predict_ket(coef,intercept,rgb_value):
# #     arr = given_arr(coef,intercept,rgb_value)
# #     max_1 = max(arr)
# #     indx1= arr.index(max_1)
# #     if indx1==0:
# #         pred = 0
# #     elif indx1==1:
# #         pred=5
# #     elif indx1==2:
# #         pred=10
# #     elif indx1 ==3:
# #         pred=50
# #     elif indx1==4:
# #         pred=100
# #     return pred

# # def predict_uro(coef,intercept,rgb_value):
# #     arr = given_arr(coef,intercept,rgb_value)
# #     max_1 = max(arr)
# #     indx1= arr.index(max_1)
# #     if indx1==0:
# #         pred = 0
# #     elif indx1==1:
# #         pred=1
# #     elif indx1==2:
# #         pred=4
# #     elif indx1 ==3:
# #         pred=8
# #     elif indx1==4:
# #         pred=12
# #     return pred
                       
# # def predict_bil(coef,intercept,rgb_value):
# #     arr= given_arr(coef,intercept,rgb_value)
# #     max_1 = max(arr)
# #     indx1= arr.index(max_1)
# #     if indx1==0:
# #         pred = 0
# #     elif indx1==1:
# #         pred=1
# #     elif indx1==2:
# #         pred=3
# #     return pred  

# # def predict_glucose(coef,intercept,rgb_value):
# #     arr= given_arr(coef,intercept,rgb_value)
# #     max_1 = max(arr)
# #     indx1= arr.index(max_1)
# #     if indx1==0:
# #         pred = 0
# #     elif indx1==1:
# #         pred=100
# #     elif indx1==2:
# #         pred=250
# #     elif indx1==3:
# #         pred=500
# #     elif indx1==4:
# #         pred=1000
# #     elif indx1==5:
# #         pred=2000
# #     return pred


# # rgb_value_wbc = {'f_p':60,'s_p':70,'w1':25,'w2':35}
# # rgb_value_ph  = {'f_p':260,'s_p':270,'w1':25,'w2':35}
# # rgb_value_sg  = {'f_p':160,'s_p':170,'w1':25,'w2':35}
# # rgb_value_glu = {'f_p':360,'s_p':370,'w1':25,'w2':35}
# # rgb_value_nit = {'f_p':460,'s_p':470,'w1':25,'w2':35}
# # rgb_value_pro = {'f_p':60,'s_p':70,'w1':25,'w2':35}
# # rgb_value_ket = {'f_p':160,'s_p':170,'w1':25,'w2':35}
# # rgb_value_uro = {'f_p':260,'s_p':270,'w1':25,'w2':35}
# # rgb_value_bil = {'f_p':360,'s_p':370,'w1':25,'w2':35}
# # rgb_value_bld = {'f_p':460,'s_p':470,'w1':25,'w2':35}