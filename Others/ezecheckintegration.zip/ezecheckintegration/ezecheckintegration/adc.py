# ads1115_module.py
import time
import board
import busio
import adafruit_ads1x15.ads1115 as ADS
from adafruit_ads1x15.analog_in import AnalogIn

class ADS1115Sensor:
    def __init__(self, gain=1):
        # Create the I2C bus
        self.i2c = busio.I2C(board.SCL, board.SDA)
        
        # Create the ADC object using the I2C bus
        self.ads = ADS.ADS1115(self.i2c)
        
        # Set the gain (controls the input voltage range)
        self.ads.gain = gain
        
        # Create single-ended input on channels
        self.channels = {
            0: AnalogIn(self.ads, ADS.P0),
            1: AnalogIn(self.ads, ADS.P1),
            2: AnalogIn(self.ads, ADS.P2),
            3: AnalogIn(self.ads, ADS.P3)
        }

    def read_channel(self, channel_num):
        """Read voltage from a specific channel"""
        if channel_num not in self.channels:
            raise ValueError(f"Invalid channel number: {channel_num}. Must be 0-3.")
            
        return self.channels[channel_num].voltage
        
    def read_all_channels(self):
        """Read voltage from all channels"""
        return {
            0: self.channels[0].voltage,
            1: self.channels[1].voltage,
            2: self.channels[2].voltage,
            3: self.channels[3].voltage
        }
        
    def monitor_channel(self, channel_num, interval=0.5, callback=None):
        """
        Continuously monitor a channel with a specified interval
        
        Args:
            channel_num: Channel number to monitor (0-3)
            interval: Time between readings in seconds
            callback: Function to call with each reading, if None will print
        """
        if channel_num not in self.channels:
            raise ValueError(f"Invalid channel number: {channel_num}. Must be 0-3.")
            
        try:
            while True:
                voltage = self.channels[channel_num].voltage
                
                if callback:
                    callback(voltage)
                else:
                    return voltage
                    
                time.sleep(interval)
                
        except KeyboardInterrupt:
            print("\nMonitoring stopped by user")

# Example usage if this module is run directly
if __name__ == "__main__":
    sensor = ADS1115Sensor()
    print("Reading ADS1115 values, press Ctrl-C to quit...")
    sensor.monitor_channel(0)