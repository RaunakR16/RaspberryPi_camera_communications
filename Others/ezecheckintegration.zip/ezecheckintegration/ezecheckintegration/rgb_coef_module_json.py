import numpy as np
import cv2
import traceback
#import coef_int
import json

class RGBModule:
    def __init__(self, debug=False):
        self.debug = debug
        self.urine_model_values = {}
        print("RGBModule initialized with debug mode:", self.debug)
        with open('urine_model_values.json', 'r') as f:
            self.urine_model_values = json.load(f)
    
    def update_coef(self, coef,file_name='urine_model_values.json', append_flag =False):
                
        # List of keys that should be converted to lists (arrays)
        list_keys = ['coef_ph', 'coef_sg', 'coef_wbc', 'int_wbc', 'coef_bld', 'int_bld', 
                    'coef_pro', 'coef_ket', 'int_ket', 'coef_uro', 'int_uro', 
                    'coef_bil', 'int_bil', 'coef_nit', 'coef_glu', 'int_glu']

        # List of keys that should be converted to float
        float_keys = ['int_ph', 'int_sg', 'int_pro','int_nit']

        # Get the first item from the list - this is already a Python dictionary
        data = json.loads(coef)  # No json.loads needed here

        data = data[0]  # Extract the first dictionary from the list

        # Process each key appropriately
        for key in list_keys:
            if key in data:
                try:
                    # Try to parse the string as JSON
                    data[key] = json.loads(data[key])
                    print(f"Converted {key} to list: {data[key][:2]}...")  # Print just the first few elements
                except json.JSONDecodeError as e:
                    print(f"Error parsing {key}: {e}")

        for key in float_keys:
            if key in data:
                try:
                    data[key] = float(data[key])
                    print(f"Converted {key} to float: {data[key]}")
                except ValueError as e:
                    print(f"Error converting {key} to float: {e}")

        # Save the dictionary to a JSON file
        with open(file_name, 'w') as f:
            json.dump(data, f, indent=4)  # indent for pretty formatting
            self.urine_model_values = json.load(f)
            #f.truncate()
    
    def predict(self, coef, intercept,rgb_value):
        val = 0
        for i in range(len(coef)):  
            val+=rgb_value[i]*coef[i]
        val = val+intercept
        return val

    def given_arr(self,coef,intercept,rgb_value):
        arr= []
        for i in range(len(coef)):
            val1 = 0
            for j in range(len(coef[i])):
                val1 += coef[i][j]*rgb_value[j]
            val1+=intercept[i]
            arr.append(val1)
        return arr
        
        
    def predict_wb(self,coef,intercept,rgb_value):
        arr = self.given_arr(coef,intercept,rgb_value)
        max_1 = max(arr)
        indx1= arr.index(max_1)
        if indx1==0:
            pred = 0
        elif indx1==1:
            pred=25
        elif indx1==2:
            pred=75
        elif indx1 ==3:
            pred=500
        return pred

    def predict_blood(self,coef,intercept,rgb_value):
        arr = self.given_arr(coef,intercept,rgb_value)
        max_1 = max(arr)
        indx1= arr.index(max_1)
        if indx1==0:
            pred = 0
        elif indx1==1:
            pred=10
        elif indx1==2:
            pred=50
        elif indx1==3:
            pred=250
        return pred

    def predict_pro_nit(self, coef,intercept,rgb_value):
        val = self.predict(coef,intercept,rgb_value)
        if val>0:
            pred =1
        else:
            pred=0
        return pred

    def predict_ket(self,coef,intercept,rgb_value):
        arr = self.given_arr(coef,intercept,rgb_value)
        max_1 = max(arr)
        indx1= arr.index(max_1)
        if indx1==0:
            pred = 0
        elif indx1==1:
            pred=5
        elif indx1==2:
            pred=10
        elif indx1 ==3:
            pred=50
        elif indx1==4:
            pred=100
        return pred

    def predict_uro(self,coef,intercept,rgb_value):
        arr = self.given_arr(coef,intercept,rgb_value)
        max_1 = max(arr)
        indx1= arr.index(max_1)
        if indx1==0:
            pred = 0
        elif indx1==1:
            pred=1
        elif indx1==2:
            pred=4
        elif indx1 ==3:
            pred=8
        elif indx1==4:
            pred=12
        return pred
                        
    def predict_bil(self,coef,intercept,rgb_value):
        arr= self.given_arr(coef,intercept,rgb_value)
        max_1 = max(arr)
        indx1= arr.index(max_1)
        if indx1==0:
            pred = 0
        elif indx1==1:
            pred=1
        elif indx1==2:
            pred=3
        return pred  

    def predict_glucose(self,coef,intercept,rgb_value):
        arr= self.given_arr(coef,intercept,rgb_value)
        max_1 = max(arr)
        indx1= arr.index(max_1)
        if indx1==0:
            pred = 0
        elif indx1==1:
            pred=100
        elif indx1==2:
            pred=250
        elif indx1==3:
            pred=500
        elif indx1==4:
            pred=1000
        elif indx1==5:
            pred=2000
        return pred

    
    def avg_rgb(self, param):
        try:
            print(f"Computing average RGB for data with shape: {np.shape(param)}")
            r = []
            g = []
            b = []
            for i in range(len(param)):
                ind = param[i]
                for j in range(len(ind)):
                    r.append(ind[j][0])
                    g.append(ind[j][1])
                    b.append(ind[j][2])
           
            if len(r) == 0:
                print("WARNING: Empty pixel array, cannot calculate average")
                return [0, 0, 0]
               
            avg_r = np.sum(r)/len(r)
            avg_g = np.sum(g)/len(g)
            avg_b = np.sum(b)/len(b)
           
            rgb_avg = [int(avg_r), int(avg_g), int(avg_b)]
            if self.debug:
                print(f"Average RGB: {rgb_avg}")
            return rgb_avg
        except Exception as e:
            print(f"ERROR in avg_rgb: {e}")
            traceback.print_exc()
            return [0, 0, 0]  # Return default value on error
 
    def detect_block(self, img_crop, f_p, s_p, w1, w2):
        try:
            if self.debug:
                print(f"Detecting block with coordinates: {f_p}:{s_p}, {w1}:{w2}")
                print(f"Image crop shape: {img_crop.shape}")
           
            if f_p >= s_p or w1 >= w2:
                print("WARNING: Invalid block coordinates")
                return [0, 0, 0]
               
            if f_p >= img_crop.shape[0] or s_p > img_crop.shape[0] or w1 >= img_crop.shape[1] or w2 > img_crop.shape[1]:
                print(f"ERROR: Block coordinates out of bounds: {f_p}:{s_p}, {w1}:{w2} for image of shape {img_crop.shape}")
                return [0, 0, 0]
               
            img_color = img_crop[f_p:s_p, w1:w2]
            if self.debug:
                print(f"Block shape: {img_color.shape}")
            return self.avg_rgb(img_color)
        except Exception as e:
            print(f"ERROR in detect_block: {e}")
            traceback.print_exc()
            return [0, 0, 0]
 
    def process_part(self, img_part, block_params):
        try:
            if self.debug:
                print(f"Processing part with {len(block_params)} parameters")
                print(f"Image part shape: {img_part.shape}")
           
            results = {}
            for param in block_params:
                if self.debug:
                    print(f"Processing parameter: {param['name']}")
                rgb_value = self.detect_block(img_part, *param['coords'])
                pred = param['predict_func'](param['coef'], param['int'], rgb_value)
                results[param['name']] = (rgb_value, pred)
                if self.debug:
                    print(f"Parameter {param['name']} RGB value: {rgb_value}")
            return results
        except Exception as e:
            print(f"ERROR in process_part: {e}")
            traceback.print_exc()
            return {}
 
    def get_rgb_values(self, image):
        try:
            # with open('urine_model_values.json', 'w') as f:
            #     self.urine_model_values = json.load(f)
            
            print("Starting RGB value extraction")
            if image is None:
                raise ValueError("Input image is None")
            
            print(f"Input image shape: {image.shape}")
            
            cv2.imwrite("input_image.jpg", image)
            print("Saved input image for debugging")
            
            # img_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            # print("Converted image to RGB")
            
            # Create a binary thresholded image
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            blur = cv2.medianBlur(gray, 5)
            sharpen_kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
            sharpen = cv2.filter2D(blur, -1, sharpen_kernel)
            print("Applied initial preprocessing")
            
            # Threshold and morph close
            thresh = cv2.threshold(sharpen, 110, 185, cv2.THRESH_BINARY_INV)[1]
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
            close = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=2)
            print("Applied thresholding and morphological operations")

            # Find start and end points
            strt_p = 0
            last_p = 0
            
            try:
                
                for i in range(len(close[0])):
                    if close[50][i]==0:
                        strt_p = i
                        if strt_p>270:
                            strt_p=260
                        break
                for j in range(len(close[5])-1,0,-1):
                    if close[50][j]==0:
                        last_p = j
                        if last_p<500:
                            last_p=510
                        break
                        
                print(f"Found start point: {strt_p}, end point: {last_p}")
                
                if strt_p >= last_p:
                    print("WARNING: Invalid start/end points detected, using defaults")
                    strt_p = 0
                    last_p = close.shape[1] - 1
            except IndexError:
                print("ERROR: Could not find start/end points, using defaults")
                strt_p = 0
                last_p = close.shape[1] - 1
            
            # Crop the image
            img_rgb_1 = image[:, strt_p:last_p]
            print(f"Cropped image shape: {img_rgb_1.shape}")

            # Apply second round of preprocessing
            gray_1 = cv2.cvtColor(img_rgb_1, cv2.COLOR_BGR2GRAY)
            blur_1 = cv2.medianBlur(gray_1, 9)
            sharpen_kernel_1 = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
            sharpen_1 = cv2.filter2D(blur_1, -1, sharpen_kernel_1)
            print("Applied second round of preprocessing")
            
            # Threshold and morph close
            thresh_1 = cv2.threshold(sharpen_1, 110, 185, cv2.THRESH_OTSU)[1]
            kernel_1 = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
            close_1 = cv2.morphologyEx(thresh_1, cv2.MORPH_ELLIPSE, kernel_1, iterations=2)
            print("Applied second round of thresholding")
 
            # Find relevant rows
            count = 0
            i = 70
            lst_no = []
 
            try:
                while i < 470 and i < close_1.shape[0]:
                    if (i+20 <= close_1.shape[0] and
                        100 <= close_1.shape[1] and
                        np.sum(close_1[i:i+20, 10:100]) >= 110000 and
                        np.sum(close_1[i:i+20, 10:100]) < 150000):
                        lst_no.append(i)
                        i = i + 60
                        count += 1
                    else:
                        i = i + 1
            except IndexError as e:
                print(f"ERROR during row finding: {e}")
                traceback.print_exc()
           
            print(f"Found {len(lst_no)} rows at positions: {lst_no}")
           
            if len(lst_no) > 0:
                print(f'Sum: {np.sum(close_1[:lst_no[0], 10:100])}')
               
                # Check if proper 10 parameters block are detected
                if ((len(lst_no) > 2 and len(lst_no) < 6) and
                    (lst_no[-1] - lst_no[0] > 260 and lst_no[-1] - lst_no[0] < 360) and
                    lst_no[-1] >= 365):
                    print('Proper parameter blocks detected')
 
                    # Process image parts
                    try:
                        if lst_no[0]<85:
                            first_part = img_rgb_1[lst_no[0]-70:lst_no[-1] + 100, 10:100]
                            sec_part = img_rgb_1[lst_no[0]-70:lst_no[-1] + 100, 170:260]
                        else:
                            first_part = img_rgb_1[lst_no[0]-85:lst_no[-1] + 100, 10:100]
                            sec_part = img_rgb_1[lst_no[0]-85:lst_no[-1] + 100, 170:260]
                       
                        print(f"First part shape: {first_part.shape}")
                        print(f"Second part shape: {sec_part.shape}")
                        
                        wb_rgb = self.detect_block(first_part, self.urine_model_values['color_block_params']['rgb_value_wbc']['f_p'], 
                                                   self.urine_model_values['color_block_params']['rgb_value_wbc']['s_p'], 
                                                   self.urine_model_values['color_block_params']['rgb_value_wbc']['w1'], 
                                                   self.urine_model_values['color_block_params']['rgb_value_wbc']['w2'])
                        ph_rgb = self.detect_block(first_part, self.urine_model_values['color_block_params']['rgb_value_ph']['f_p'],
                                                   self.urine_model_values['color_block_params']['rgb_value_ph']['s_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_ph']['w1'],
                                                    self.urine_model_values['color_block_params']['rgb_value_ph']['w2'])
                        sg_rgb = self.detect_block(first_part, self.urine_model_values['color_block_params']['rgb_value_sg']['f_p'],
                                                   self.urine_model_values['color_block_params']['rgb_value_sg']['s_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_sg']['w1'],
                                                    self.urine_model_values['color_block_params']['rgb_value_sg']['w2'])
                        nit_rgb = self.detect_block(first_part, self.urine_model_values['color_block_params']['rgb_value_nit']['f_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_nit']['s_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_nit']['w1'],
                                                    self.urine_model_values['color_block_params']['rgb_value_nit']['w2'])
                        glu_rgb = self.detect_block(first_part, self.urine_model_values['color_block_params']['rgb_value_glu']['f_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_glu']['s_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_glu']['w1'],
                                                    self.urine_model_values['color_block_params']['rgb_value_glu']['w2'])
                        protien_rgb = self.detect_block(sec_part, self.urine_model_values['color_block_params']['rgb_value_pro']['f_p'],
                                                        self.urine_model_values['color_block_params']['rgb_value_pro']['s_p'],
                                                        self.urine_model_values['color_block_params']['rgb_value_pro']['w1'],
                                                        self.urine_model_values['color_block_params']['rgb_value_pro']['w2'])
                        ket_rgb = self.detect_block(sec_part, self.urine_model_values['color_block_params']['rgb_value_ket']['f_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_ket']['s_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_ket']['w1'],
                                                    self.urine_model_values['color_block_params']['rgb_value_ket']['w2'])
                        uro_rgb = self.detect_block(sec_part, self.urine_model_values['color_block_params']['rgb_value_uro']['f_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_uro']['s_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_uro']['w1'],
                                                    self.urine_model_values['color_block_params']['rgb_value_uro']['w2'])
                        bil_rgb = self.detect_block(sec_part, self.urine_model_values['color_block_params']['rgb_value_bil']['f_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_bil']['s_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_bil']['w1'],
                                                    self.urine_model_values['color_block_params']['rgb_value_bil']['w2'])
                        blood_rgb = self.detect_block(sec_part, self.urine_model_values['color_block_params']['rgb_value_bld']['f_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_bld']['s_p'],
                                                    self.urine_model_values['color_block_params']['rgb_value_bld']['w1'],
                                                    self.urine_model_values['color_block_params']['rgb_value_bld']['w2'])
                        
                        results_dict = {
                                '0':{
                                    'Type': 'Leukocytes',
                                    'RGB': wb_rgb,
                                    'PRED': self.predict_wb(self.urine_model_values['coef_wbc'], self.urine_model_values['int_wbc'], wb_rgb)
                                },
                                '1':{
                                    'Type': 'PH',
                                    'RGB': ph_rgb,
                                    'PRED': self.predict(self.urine_model_values['coef_ph'], self.urine_model_values['int_ph'], ph_rgb)
                                },
                                '2':{
                                    'Type': 'SG',
                                    'RGB': sg_rgb,
                                    'PRED': self.predict(self.urine_model_values['coef_sg'], self.urine_model_values['int_sg'], sg_rgb)
                                },
                                '3':{
                                    'Type': 'Glucose',
                                    'RGB': glu_rgb,
                                    'PRED': self.predict_glucose(self.urine_model_values['coef_glu'], self.urine_model_values['int_glu'], glu_rgb)
                                },
                                '4':{
                                    'Type': 'Nitrites',
                                    'RGB': nit_rgb,
                                    'PRED': self.predict_pro_nit(self.urine_model_values['coef_nit'], self.urine_model_values['int_nit'], nit_rgb)
                                },
                                '5':{
                                    'Type': 'Protien',
                                    'RGB': protien_rgb,
                                    'PRED': self.predict_pro_nit(self.urine_model_values['coef_pro'], self.urine_model_values['int_pro'], protien_rgb)
                                },
                                '6':{
                                    'Type': 'Ketones',
                                    'RGB': ket_rgb,
                                    'PRED': self.predict_ket(self.urine_model_values['coef_ket'], self.urine_model_values['int_ket'], ket_rgb)
                                },
                                '7':{
                                    'Type': 'Urobilinogen',
                                    'RGB': uro_rgb,
                                    'PRED': self.predict_uro(self.urine_model_values['coef_uro'], self.urine_model_values['int_uro'], uro_rgb)
                                },
                                '8':{
                                    'Type': 'Bilirubin',
                                    'RGB': bil_rgb,
                                    'PRED': self.predict_bil(self.urine_model_values['coef_bil'], self.urine_model_values['int_bil'], bil_rgb)
                                },
                                '9':{
                                    'Type': 'Blood',
                                    'RGB': blood_rgb,
                                    'PRED': self.predict_blood(self.urine_model_values['coef_bld'], self.urine_model_values['int_bld'], blood_rgb)
                                }
                        }
                       
                        print("Successfully extracted all RGB values")
                        return results_dict
                    except Exception as e:
                        print(f"ERROR during parts processing: {e}")
                        traceback.print_exc()
                        return {}
                else:
                    print("WARNING: Improper block configuration detected")
                    return {}
            else:
                print("WARNING: No rows detected")
                return {}
               
        except Exception as e:
            print(f"ERROR in get_rgb_values: {e}")
            traceback.print_exc()
            return {}
