import cv2
import numpy as np
from PIL import Image
import os
import datetime
import glob

class pos:
    def __init__(self):
        print('Position of strip is being verified')
        # Clean up previous test images on initialization
        pass
    
    def cleanup_previous_images(self):
        """Remove all previous test position verify images"""
        for old_file in glob.glob("test_position_verify_*.jpeg"):
            try:
                os.remove(old_file)
                print(f"Removed old test image: {old_file}")
            except Exception as e:
                print(f"Could not remove {old_file}: {e}")
    
    def ver_pos(self, image):
        self.cleanup_previous_images()
        print('Verifying position of strip')
        
        # Generate timestamp for the filename
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        image_filename = f"test_position_verify_{timestamp}.jpeg"
        # Save the input image with timestamp
        img = Image.fromarray(image)
        img.save(image_filename)
        print(f"Array to image saved as {image_filename}")
        
        img_rgb = image
        print('Image shape:', img_rgb.shape)

        try: 
            # create a binary thresholded image on hue between red and yellow
            gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
            blur = cv2.medianBlur(gray, 5)
            sharpen_kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
            sharpen = cv2.filter2D(blur, -1, sharpen_kernel)
            print("created sharpen image")

            # Threshold and morph close
            thresh = cv2.threshold(sharpen, 110, 185, cv2.THRESH_BINARY_INV)[1]
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
            close = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=2)
            print("thresh and morph close done")

            strt_p = 0
            last_p = 0
            for i in range(len(close[0])):
                if close[50][i]==0:
                    strt_p = i
                    if strt_p>270:
                        strt_p=260
                    break
            for j in range(len(close[5])-1,0,-1):
                if close[50][j]==0:
                    last_p = j
                    if last_p<500:
                        last_p=510
                    break
            img_rgb_1 = img_rgb[:,strt_p:last_p]
            
            print("image cropped")

            gray_1 = cv2.cvtColor(img_rgb_1, cv2.COLOR_BGR2GRAY)
            blur_1 = cv2.medianBlur(gray_1, 9)
            sharpen_kernel_1 = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
            sharpen_1 = cv2.filter2D(blur_1, -1, sharpen_kernel_1)
            print("2nd sharpen image created")

            # Threshold and morph close
            thresh_1 = cv2.threshold(sharpen_1,110, 185, cv2.THRESH_OTSU)[1]
            kernel_1 = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
            close_1 = cv2.morphologyEx(thresh_1, cv2.MORPH_ELLIPSE, kernel_1, iterations=2)
            print("2nd thresh and morph close done")

            count = 0
            i = 85
            lst_no = []
            # for i in range(strt_p,end_p):
            while i<470:
                #print('val',i)
                if np.sum(close_1[i:i+20,10:100]) >=110000 and np.sum(close_1[i:i+20,10:100])<150000:
                    lst_no.append(i)
                    i = i+60
                    count +=1

                else:
                    i=i+1
            print('Sum: ',np.sum(close_1[:lst_no[0],10:100]))
            print(lst_no)
            if len(lst_no)>0:
                if ((lst_no[-1] - lst_no[0] >260) and (lst_no[-1]-lst_no[0]<360))  and (len(lst_no)>2 and len(lst_no)<6) and lst_no[-1]>=365:
                    print('true')
                    return('true')
                else:
                    print('false')
                    return('false')
        except Exception as e:
            print(f"Error during image processing: {e}")
            return ('false')