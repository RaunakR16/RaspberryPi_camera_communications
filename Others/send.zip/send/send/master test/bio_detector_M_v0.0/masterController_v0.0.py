# ==============================
# MASTER CONTROLLER CODE 
# ==============================

import time
import spidev
import RPi.GPIO as GPIO
import datetime
import json
from motor_module import MotorModule
from image_packet_handler import decode_packets_to_image

# --- SPI and GPIO Setup ---
spi = spidev.SpiDev()
spi.open(0, 0)  # Using SPI0 CE0
spi.max_speed_hz = 500000  # 500 kHz

# --- GPIO Setup for Slave Selects ---
SLAVE_SELECTS = {
    1: 8,
    2: 7,
    3: 25,
    4: 24,
    5: 23
}
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
for pin in SLAVE_SELECTS.values():
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, GPIO.HIGH)  # Default to inactive

# --- Initialize Motor ---
motor = MotorModule()

# --- Select Slave Device ---
def select_slave(slave_id):
    for pin in SLAVE_SELECTS.values():
        GPIO.output(pin, GPIO.HIGH)
    GPIO.output(SLAVE_SELECTS[slave_id], GPIO.LOW)

# --- Deselect All Slaves ---
def deselect_all():
    for pin in SLAVE_SELECTS.values():
        GPIO.output(pin, GPIO.HIGH)

# --- Receive Packets from Slave ---
def receive_image_packets(slave_id):
    select_slave(slave_id)
    spi.xfer2([0xA0])  # Request image

    # Read number of packets
    total_packets = spi.readbytes(1)[0]
    print(f"[Master] Expecting {total_packets} packets from Slave {slave_id}")

    packets = []
    for i in range(total_packets):
        length = spi.readbytes(2)
        packet_size = int.from_bytes(length, byteorder='big')
        packet_data = bytearray()
        for _ in range(packet_size):
            packet_data.append(spi.xfer2([0x00])[0])
        try:
            packet_json = json.loads(packet_data.decode('utf-8'))
            packets.append(packet_json)
        except Exception as e:
            print(f"[Master] Error parsing packet {i}: {e}")

    deselect_all()
    filepath = decode_packets_to_image(packets)
    print(f"[Master] Image from Slave {slave_id} saved at {filepath}")

# --- Main Flow ---
def main():
    print("[Master] Starting system...")

    # 1. Eject Tray
    motor.rotate_clockwise()
    time.sleep(60)  # Wait 1 min

    # 2. Insert Tray
    motor.rotate_anticlockwise()
    time.sleep(2)

    # 3. Activate Slaves and check for sample
    sample_detected = []
    for i in SLAVE_SELECTS:
        select_slave(i)
        spi.xfer2([0xB1])  # Ask for sample presence check
        response = spi.readbytes(1)[0]  # 1 = sample detected
        if response == 1:
            sample_detected.append(i)
            print(f"[Master] Sample detected on Slave {i}")
        else:
            print(f"[Master] No sample on Slave {i}")
        deselect_all()

    # 4. Request image capture from valid slaves
    for sid in sample_detected:
        receive_image_packets(sid)

    print("[Master] Task complete.")
    print("Sending data to the user.")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("[Master] Interrupted.")
    finally:
        GPIO.cleanup()
        spi.close()
