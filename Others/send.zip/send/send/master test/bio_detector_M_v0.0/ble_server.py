from bluezero import peripheral
import json

ADAPTER_ADDR = 'B8:27:EB:0C:E2:D3'  # Replace with your Pi's Bluetooth MAC

data = {
    "Name": "Raunak",
    "Age": 21,
    "Temperature": 36.6,
    "Humidity": 70,
    "Status": "Active",
    "Location": {"lat": 22.5726, "lon": 88.3639},
    "Sensors": {
        "IR": [1023, 1020, 1015],
        "UV": [200, 180, 175],
        "Gas": {"CO2": 412, "CO": 0.04, "NO2": 0.02}
    },
    "Log": [
        {"time": "2025-06-16T12:00:00", "event": "start"},
        {"time": "2025-06-16T12:05:00", "event": "read"},
        {"time": "2025-06-16T12:10:00", "event": "send"}
    ]
}

# Convert dictionary to bytes
def dict_as_bytes():
    return list(json.dumps(data).encode('utf-8'))

# Setup Peripheral
my_device = peripheral.Peripheral(
    adapter_address=ADAPTER_ADDR,
    local_name='MasterRpi'
)



# Add service
my_device.add_service(
    srv_id=1,
    uuid='12345678-1234-5678-1234-56789abcdef0',
    primary=True
)

# Add characteristic
my_device.add_characteristic(
    srv_id=1,
    chr_id=1,
    uuid='abcd1234-5678-4321-1234-fedcba987654',
    value=dict_as_bytes(),
    notifying=False,
    flags=['read']
)

# Start advertising
my_device.publish()
