#=====================================
# IMAGE TO BYTE TO PACKAGE CONVERTER 
#=====================================
import json
import base64
import os
import datetime

PACKET_SIZE = 150  # byte per packet


def encode_image_to_packets(img_bytes, slave_id):
    """
    Encodes the image bytes into JSON packets for transmission.

    Args:
        img_bytes (bytes): Image data in bytes
        slave_id (int): ID of the slave for naming reference

    Returns:
        List[dict]: A list of JSON-serializable packets
    """
    b64_img = base64.b64encode(img_bytes).decode('utf-8')
    total_length = len(b64_img)
    packets = []
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    for i in range(0, total_length, PACKET_SIZE):
        chunk = b64_img[i:i + PACKET_SIZE]
        packet = {
            'id': slave_id,
            'timestamp': timestamp,
            'packet_index': i // PACKET_SIZE,
            'total_packets': (total_length + PACKET_SIZE - 1) // PACKET_SIZE,
            'data': chunk
        }
        packets.append(packet)

    return packets


def decode_packets_to_image(packets, output_dir="."):
    """
    Reassembles image from a list of received packets and writes to a file.

    Args:
        packets (List[dict]): List of packets received
        output_dir (str): Directory to save the reconstructed image

    Returns:
        str: Path to the saved image file
    """
    if not packets:
        raise ValueError("No packets received")

    # Sort packets by index to ensure correct order
    packets.sort(key=lambda p: p['packet_index'])

    full_b64 = ''.join(packet['data'] for packet in packets)
    img_bytes = base64.b64decode(full_b64.encode('utf-8'))

    slave_id = packets[0]['id']
    timestamp = packets[0]['timestamp']
    filename = f"image_slave{slave_id}_{timestamp}.jpg"
    filepath = os.path.join(output_dir, filename)

    with open(filepath, "wb") as f:
        f.write(img_bytes)

    return filepath
