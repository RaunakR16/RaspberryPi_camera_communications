# ==============================
# SLAVE CONTROLLER CODE 
# ==============================
import time
import spidev
import RPi.GPIO as GPIO
import json
from camera_module_v4_3 import CameraModule
from image_packet_handler import encode_image_to_packets

# Constants
CS_PIN = 17
SAMPLE_CHECK_CMD = 0xB1
IMAGE_CAPTURE_CMD = 0xA0
SLAVE_ID = 1  # Change this per device

# Setup GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(CS_PIN, GPIO.IN)

# SPI setup
spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 500000 # 50hz

# Camera setup
camera = CameraModule()

# Stub for sample detection
def is_sample_present():
    print("[Slave] Checking for sample presence...")
    return True

# Wait for master to activate via CS
def wait_for_command():
    while True:
        if GPIO.input(CS_PIN) == GPIO.LOW:
            cmd = spi.readbytes(1)[0]
            print(f"[Slave] Command received: {cmd}")
            return cmd

# Send packetized image data
def send_packetized_image(img_bytes):
    packets = encode_image_to_packets(img_bytes, SLAVE_ID)
    total_packets = len(packets)
    spi.xfer2([total_packets])
    for packet in packets:
        payload = json.dumps(packet).encode('utf-8')
        size_bytes = len(payload).to_bytes(2, byteorder='big')
        spi.xfer2(list(size_bytes))
        for byte in payload:
            spi.xfer2([byte])
    print(f"[Slave] Sent {total_packets} packets.")

# Main loop
def main():
    print("[Slave] Ready.")
    while True:
        cmd = wait_for_command()

        if cmd == SAMPLE_CHECK_CMD:
            present = is_sample_present()
            spi.xfer2([1 if present else 0])
            time.sleep(0.5)

        elif cmd == IMAGE_CAPTURE_CMD:
            print("[Slave] Capturing image...")
            img = camera.capture_image(apply_color_correction=True, byte_image=True)
            if img:
                send_packetized_image(img)
            else:
                print("[Slave] Image capture failed.")
            time.sleep(0.5)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("[Slave] Interrupted by user.")
    finally:
        camera.close()
        spi.close()
        GPIO.cleanup()
