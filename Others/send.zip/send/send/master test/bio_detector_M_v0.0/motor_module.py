#==========================
# MOTOR CONTROLLER
#==========================

import RPi.GPIO as GPIO
import time
import threading

class MotorModule:
    def __init__(self):
        self.MOTOR_IN1_PIN = 12
        self.MOTOR_IN2_PIN = 13
        self.DEFAULT_SPEED = 100  # Default speed at 100%
        self.DEFAULT_TIME_cw = 1.3
        self.DEFAULT_TIME_acw = 1.45

        self.current_direction = "stopped"
        self.current_speed = 0
        self.timer = None
        self.last_command = None 

        # Setup GPIO
        self.setup()

    def setup(self):
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        GPIO.setup(self.MOTOR_IN1_PIN, GPIO.OUT)
        GPIO.setup(self.MOTOR_IN2_PIN, GPIO.OUT)

        self.pwm_in1 = GPIO.PWM(self.MOTOR_IN1_PIN, 100)  # 100 Hz frequency
        self.pwm_in2 = GPIO.PWM(self.MOTOR_IN2_PIN, 100)

        self.pwm_in1.start(0)
        self.pwm_in2.start(0)

        print('Motor Module Setup Complete')

    def rotate_clockwise(self, speed=None, run_time=None):
        if speed is None:
            speed = self.DEFAULT_SPEED
        if run_time is None:
            run_time = self.DEFAULT_TIME_cw

        speed = max(0, min(100, speed))

        print(f'Setting motor clockwise at {speed}% speed for {run_time} seconds')
        self.pwm_in1.ChangeDutyCycle(0)
        self.pwm_in2.ChangeDutyCycle(speed)

        self.current_direction = "clockwise"
        self.current_speed = speed
        self.last_command = "cw"

        if self.timer and self.timer.is_alive():
            self.timer.cancel()

        
        self.timer = threading.Timer(run_time, self.stop)
        self.timer.start()

    def rotate_anticlockwise(self, speed=None, run_time=None):
        if speed is None:
            speed = self.DEFAULT_SPEED
        if run_time is None:
            run_time = self.DEFAULT_TIME_acw

        
        speed = max(0, min(100, speed))

        print(f'Setting motor anti-clockwise at {speed}% speed for {run_time} seconds')
        self.pwm_in1.ChangeDutyCycle(speed)
        self.pwm_in2.ChangeDutyCycle(0)

        self.current_direction = "anti-clockwise"
        self.current_speed = speed
        self.last_command = "acw"

        if self.timer and self.timer.is_alive():
            self.timer.cancel()

       
        self.timer = threading.Timer(run_time, self.stop)
        self.timer.start()

    def stop(self):
        print('Stopping motor')
        self.pwm_in1.ChangeDutyCycle(0)
        self.pwm_in2.ChangeDutyCycle(0)

        self.current_direction = "stopped"
        self.current_speed = 0

        
        if self.timer and self.timer.is_alive():
            self.timer.cancel()

    def get_status(self):
        return {
            "speed": self.current_speed,
            "direction": self.current_direction,
            "last_command": self.last_command
        }

    def cleanup(self):
        self.stop()
        self.pwm_in1.stop()
        self.pwm_in2.stop()
        GPIO.cleanup()


def main():
    motor = MotorModule()

    print("Motor Control - Alternating Commands Required")
    print("cw - Clockwise")
    print("acw - AntiClockwise")
    print("Press Ctrl+C to exit")
    print("\nNote: After using 'cw', only 'acw' will be accepted, and vice versa")

    try:
        # First command can be either cw or acw
        while True:
            com = input("Enter command (cw/acw): ")
            
            
            if motor.last_command is None:
               
                if com not in ["cw", "acw"]:
                    print("Invalid command. Use 'cw' or 'acw'.")
                    continue
            else:
                
                if motor.last_command == "cw" and com != "acw":
                    print("After 'cw', only 'acw' is accepted. Please enter 'acw'.")
                    continue
                elif motor.last_command == "acw" and com != "cw":
                    print("After 'acw', only 'cw' is accepted. Please enter 'cw'.")
                    continue
            
           
            if com == "cw":
                motor.rotate_clockwise()
            elif com == "acw":
                motor.rotate_anticlockwise()
            
            
#            time.sleep(motor.DEFAULT_TIME + 0.2)  # Adding a small buffer

    except KeyboardInterrupt:
        print("Program Stopped by User")
    finally:
        motor.cleanup()
        print("GPIO cleaned up")


if __name__ == "__main__":
    main()
