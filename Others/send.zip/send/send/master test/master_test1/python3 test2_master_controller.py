# ==============================
# TEST 2 MASTER CONTROLLER CODE
# ==============================
import time
import spidev
import RPi.GPIO as GPIO
import json
from image_packet_handler import decode_packets_to_image

# SPI device map
SPI_DEVICES = {
    1: (0, 0),  # SPI0 CS0 (Slave 1)
    2: (0, 1),  # SPI0 CS1 (Slave 2)
    3: (1, 0),  # SPI1 CS0 (Slave 3)
    4: (1, 1),  # SPI1 CS1 (Slave 4)
    5: (1, 2)   # SPI1 CS2 (Slave 5)
}

# GPIO broadcast trigger pin
TRIGGER_GPIO = 22

# SPI command
CAPTURE_CMD = 0xA0

# Setup GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIGGER_GPIO, GPIO.OUT)
GPIO.output(TRIGGER_GPIO, GPIO.LOW)

def trigger_all_slaves():
    print("[Master] Broadcasting capture trigger to all selected slaves...")
    GPIO.output(TRIGGER_GPIO, GPIO.HIGH)
    time.sleep(0.5)
    GPIO.output(TRIGGER_GPIO, GPIO.LOW)
    print("[Master] Trigger pulse sent.")

def receive_image(spi_bus, spi_cs, slave_id):
    print(f"[Master] Opening SPI({spi_bus}, {spi_cs}) for Slave {slave_id}")
    spi = spidev.SpiDev()
    spi.open(spi_bus, spi_cs)
    spi.max_speed_hz = 500000

    total_packets = spi.readbytes(1)[0]
    if total_packets == 0:
        print(f"[Master] No packets received from Slave {slave_id}")
        return

    print(f"[Master] Receiving {total_packets} packets from Slave {slave_id}")
    packets = []
    for i in range(total_packets):
        length = spi.readbytes(2)
        packet_size = int.from_bytes(length, byteorder='big')
        packet_data = bytearray()
        for _ in range(packet_size):
            packet_data.append(spi.xfer2([0x00])[0])
        packet_json = json.loads(packet_data.decode('utf-8'))
        packets.append(packet_json)

    filepath = decode_packets_to_image(packets, output_dir="images")
    print(f"[Master] Image from Slave {slave_id} saved at: {filepath}")
    spi.close()

def main():
    print("--- TEST 2: Simultaneous Capture, Sequential Transfer ---")
    print("Available Slaves: 1 2 3 4 5")
    selected = input("Enter slave numbers to trigger (space-separated): ")

    try:
        slave_ids = [int(sid) for sid in selected.strip().split() if int(sid) in SPI_DEVICES]
        if not slave_ids:
            print("No valid slaves selected. Exiting.")
            return

        # Send GPIO trigger to all selected slaves
        trigger_all_slaves()

        # Sequentially receive images from each slave
        for sid in slave_ids:
            bus, cs = SPI_DEVICES[sid]
            time.sleep(0.5)
            receive_image(bus, cs, sid)

        print("\n[Master] All images received and saved.")

    except Exception as e:
        print(f"[Master] Error: {e}")
    finally:
        GPIO.cleanup()

if __name__ == "__main__":
    main()
