# ==============================
# SPI TEST MASTER CODE
# ==============================
import time
import spidev
import RPi.GPIO as GPIO
import json
from image_packet_handler import decode_packets_to_image

# Define Slave Select GPIO mapping
SLAVE_SELECTS = {
    1: 8,
    2: 7,
    3: 25,
    4: 24,
    5: 23
}

# SPI setup
spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 500000

# GPIO setup
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
for pin in SLAVE_SELECTS.values():
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, GPIO.HIGH)

# SPI commands
IMAGE_CAPTURE_CMD = 0xA0

# Select and deselect slaves

def select_slave(slave_id):
    for pin in SLAVE_SELECTS.values():
        GPIO.output(pin, GPIO.HIGH)
    GPIO.output(SLAVE_SELECTS[slave_id], GPIO.LOW)

def deselect_all():
    for pin in SLAVE_SELECTS.values():
        GPIO.output(pin, GPIO.HIGH)

# Receive packets and decode image

def receive_image_packets(slave_id):
    select_slave(slave_id)
    spi.xfer2([IMAGE_CAPTURE_CMD])
    total_packets = spi.readbytes(1)[0]
    print(f"Receiving {total_packets} packets from Slave {slave_id}")

    packets = []
    for i in range(total_packets):
        length = spi.readbytes(2)
        packet_size = int.from_bytes(length, byteorder='big')
        packet_data = bytearray()
        for _ in range(packet_size):
            packet_data.append(spi.xfer2([0x00])[0])
        packet_json = json.loads(packet_data.decode('utf-8'))
        packets.append(packet_json)

    deselect_all()
    filepath = decode_packets_to_image(packets, output_dir="images")
    print(f"Image from Slave {slave_id} saved as {filepath}\n")

# Main function

def main():
    print("--- SPI Test: Image Capture from Selected Slaves ---")
    print("Available Slaves: 1 2 3 4 5")
    selected = input("Enter slave numbers to capture from (space-separated): ")
    try:
        slave_ids = [int(sid) for sid in selected.strip().split() if int(sid) in SLAVE_SELECTS]
        if not slave_ids:
            print("No valid slaves selected. Exiting.")
            return

        for sid in slave_ids:
            print(f"\nRequesting image from Slave {sid}...")
            receive_image_packets(sid)

        print("\nAll selected images captured successfully.")

    except Exception as e:
        print(f"Error: {e}")
    finally:
        spi.close()
        GPIO.cleanup()

if __name__ == "__main__":
    main()
