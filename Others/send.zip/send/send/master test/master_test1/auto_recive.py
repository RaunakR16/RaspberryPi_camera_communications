# ==============================
# MASTER DEBUG MODE - Passive SPI Receive (Shared CS0 - GPIO 8)
# ==============================
import time
import spidev
import json
from image_packet_handler import decode_packets_to_image

# Use hardware CS0 (GPIO 8)
CS_LINE = 0  # SPI CS0

# Setup SPI
spi = spidev.SpiDev()
spi.open(0, CS_LINE)
spi.max_speed_hz = 500000

def receive_image_from_slave():
    print("[Master Debug] Listening for image packets on CS0...")

    # Wait until we receive a non-zero packet count
    total_packets = 0
    attempts = 0
    while total_packets == 0 and attempts < 100:
        total_packets = spi.readbytes(1)[0]
        if total_packets == 0:
            time.sleep(0.1)
            attempts += 1

    if total_packets == 0:
        print("[Master Debug] No packets received from slave. Timeout.")
        return

    print(f"[Master Debug] Receiving {total_packets} packets")
    packets = []
    for i in range(total_packets):
        length = spi.readbytes(2)
        packet_size = int.from_bytes(length, byteorder='big')
        packet_data = bytearray()
        for _ in range(packet_size):
            packet_data.append(spi.xfer2([0x00])[0])
        packet_json = json.loads(packet_data.decode('utf-8'))
        packets.append(packet_json)

    filepath = decode_packets_to_image(packets, output_dir="images")
    print(f"[Master Debug] Image saved at: {filepath}")

def main():
    input("[Master Debug] Press Enter to receive image from slave...")
    receive_image_from_slave()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("[Master Debug] Interrupted.")
    finally:
        spi.close()
