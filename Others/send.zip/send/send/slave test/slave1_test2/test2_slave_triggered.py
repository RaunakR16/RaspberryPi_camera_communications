# ==============================
# TEST 2 SLAVE CONTROLLER CODE
# ==============================
import time
import spidev
import RPi.GPIO as GPIO
import json
from camera_module_v4_3 import CameraModule
from image_packet_handler import encode_image_to_packets

# === SET THIS PER SLAVE ===
SLAVE_ID = 1  # Change this per device (1 to 5)
TRIGGER_GPIO = 27  # Shared input pin from master's trigger (GPIO 22)

# SPI Setup
spi = spidev.SpiDev()
spi.open(0, 0)  # All slaves listen on /dev/spidev0.0
spi.max_speed_hz = 500000

# Camera setup
camera = CameraModule()

# GPIO setup
GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIGGER_GPIO, GPIO.IN)

# Wait for rising edge trigger
def wait_for_trigger():
    print("[Slave] Waiting for capture trigger from master...")
    GPIO.wait_for_edge(TRIGGER_GPIO, GPIO.RISING)
    print("[Slave] Trigger received! Capturing image...")

def send_packetized_image(img_bytes):
    packets = encode_image_to_packets(img_bytes, SLAVE_ID)
    total_packets = len(packets)
    spi.xfer2([total_packets])

    for packet in packets:
        payload = json.dumps(packet).encode('utf-8')
        size_bytes = len(payload).to_bytes(2, byteorder='big')
        spi.xfer2(list(size_bytes))
        for byte in payload:
            spi.xfer2([byte])
    print(f"[Slave] Sent {total_packets} packets.")

def main():
    try:
        wait_for_trigger()
        img = camera.capture_image(apply_color_correction=True, byte_image=True)
        if img:
            send_packetized_image(img)
        else:
            print("[Slave] Image capture failed.")

    except Exception as e:
        print(f"[Slave] Error: {e}")
    finally:
        camera.close()
        spi.close()
        GPIO.cleanup()

if __name__ == "__main__":
    main()
