import time
import spidev
import RPi.GPIO as GPIO
import json
from camera_module_v4_3 import CameraModule
from image_packet_handler import encode_image_to_packets

# ================================================ SET THESE PER SLAVE ===
SLAVE_ID = 1  # Change this for each slave (1 to 5)
SPI_BUS = 0 
SPI_CS = 0
TRIGGER_GPIO = 27  

# SPI Setup
spi = spidev.SpiDev()
spi.open(SPI_BUS, SPI_CS)
spi.max_speed_hz = 1000000  # 1 MHz

# Camera setup
camera = CameraModule()

# GPIO setup
GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIGGER_GPIO, GPIO.IN)

def wait_for_trigger():
    print(f"[Slave {SLAVE_ID}] Waiting for capture trigger from master...")
    GPIO.wait_for_edge(TRIGGER_GPIO, GPIO.RISING)
    print(f"[Slave {SLAVE_ID}] Trigger received! Capturing image...")

def send_packetized_image(img_bytes):
    packets = encode_image_to_packets(img_bytes, SLAVE_ID)
    total_packets = len(packets)
    spi.xfer2([total_packets])  # Send total packet count

    for packet in packets:
        payload = json.dumps(packet).encode('utf-8')
        size_bytes = len(payload).to_bytes(2, byteorder='big')
        spi.xfer2(list(size_bytes))  # Send packet size
        for byte in payload:
            spi.xfer2([byte])  # Send packet data byte-by-byte
    print(f"[Slave {SLAVE_ID}] Sent {total_packets} packets.")

def main():
    try:
        wait_for_trigger()
        img = camera.capture_image(apply_color_correction=True, byte_image=True)
        if img:
            send_packetized_image(img)
        else:
            print(f"[Slave {SLAVE_ID}] Image capture failed.")
    except Exception as e:
        print(f"[Slave {SLAVE_ID}] Error: {e}")
    finally:
        camera.close()
        spi.close()
        GPIO.cleanup()

if __name__ == "__main__":
    main()
